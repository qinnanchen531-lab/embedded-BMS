#ifndef SCALER_PARAMS_H
#define SCALER_PARAMS_H

#define NUM_FEATURES 10

static const float feature_a[NUM_FEATURES] = {
    0.11440520f,
    1.39870997f,
    13.65514388f,
    0.37443774f,
    0.33288183f,
    2.30996180f,
    0.00033847f,
    0.00102119f,
    0.11659638f,
    1.55195945f,
};

static const float feature_b[NUM_FEATURES] = {
    -2.87060136f,
    -0.31653726f,
    -1.63199414f,
    -0.00000000f,
    -0.00000000f,
    -1.66853376f,
    -0.00033424f,
    0.00568767f,
    -0.00000000f,
    -0.98471101f,
};

#define NUM_TARGETS 1

static const float target_a[NUM_TARGETS] = {
    0.37732171f,
};

static const float target_b[NUM_TARGETS] = {
    -1.65025830f,
};

#endif
