import torch
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

from torch.utils.data import DataLoader
from pathlib import Path
import joblib

from config_utils import load_config
from model_def import LSTMModel
from data_utils import WindowBuilder,WindowDataset

cfg=load_config()
SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent
DATA_DIR = ROOT_DIR / cfg["paths"]["data_dir"]
PARQUET_PATTERN = cfg["paths"]["parquet_pattern"]
nums=range(1,30,2)
filepaths=[]
for num in nums:
    path=DATA_DIR/PARQUET_PATTERN.format(num=num)
    filepaths.append(path)

filepaths_mcu=[]
for num in nums:
    path=ROOT_DIR/f"data/mcu_soh/mcu_soh_C{num:02d}.parquet"
    filepaths_mcu.append(path)


builder=WindowBuilder(
    features=cfg["data"]["feature_cols"],
    target=cfg["data"]["target_col"],
    window=cfg["window"]["size"],
    stride=cfg["window"]["stride"]
)
scalers=joblib.load("scalers.pkl")
targ_scalers=scalers["target_scaler"]



def calc_metrics(pred, true):
    rmse = np.sqrt(np.mean((pred-true)**2))
    mae  = np.mean(np.abs(pred-true))
    return rmse, mae
def inverse_scale(val,scaler):
    if hasattr(scaler,"data_min_"):
        return val*scaler.data_range_[0]+scaler.data_min_[0]
    elif hasattr(scaler, "center_"):
        return val * scaler.scale_[0] + scaler.center_[0]
    elif hasattr(scaler, "mean_"):  # StandardScaler
        return val * scaler.scale_[0] + scaler.mean_[0]
    else:
        raise ValueError("Unknown scaler type")
model=LSTMModel()
model.load_state_dict(torch.load("best_lstm_model_1h.pth"))
model.eval()

def rmse(pred, target):
    return torch.sqrt(((pred - target) ** 2).mean())
def mae(pred, target):
    return torch.mean(torch.abs(pred - target)).item()


y_true_dict={}
y_pred_dict={}
y_mcu_dict={}



for batt_id in range(15,16):
    df=pd.read_parquet(filepaths[batt_id-1])
    X_list,Y_list,_=builder.build(df)
    test_ds=WindowDataset(X_list,Y_list)
    test_loader=DataLoader(test_ds,batch_size=1,shuffle=False)  

    y_true_list_soh = []
    y_pred_list_soh = []
    

    with torch.no_grad():
        for Xb, Yb in test_loader:
            output= model(Xb)  
            y = output[0].numpy()
            y_soh=y[:, 0]
 
            
            y_pred_list_soh.append(y[:, 0])
    
            Yb_np = Yb.numpy()
            y_true_list_soh.append(Yb_np[:, 0])
            



    
    y_true_soh = np.concatenate(y_true_list_soh, axis=0)

    y_pred_soh = np.concatenate(y_pred_list_soh, axis=0)
    y_mcu_list_soh = pd.read_parquet(filepaths_mcu[batt_id-1])["SoH_lstm"]
    idx=list(range(168*60, len(y_mcu_list_soh), 24*60))
    y_mcu_soh = y_mcu_list_soh[idx].reset_index(drop=True)


    y_true_dict[batt_id]={"soh": y_true_soh}
    y_pred_dict[batt_id]={"soh": y_pred_soh}
    y_mcu_dict[batt_id]={"soh": y_mcu_soh}

    rmse_soh, mae_soh = calc_metrics(y_pred_soh, y_true_soh)
    rmse_mcu, mae_mcu = calc_metrics(y_mcu_soh, y_true_soh)

    print(f"Battery {batt_id}:")
    print(f"  SOH      - RMSE: {rmse_soh:.6f}, MAE: {mae_soh:.6f}")
    print(f"  MCU      - RMSE: {rmse_mcu:.6f}, MAE: {mae_mcu:.6f}")

    plt.figure(figsize=(10,5))
    plt.plot(y_true_soh, color='blue',label='Ground Truth')
    plt.plot(y_pred_soh,  color='red', label=f'PC: RMSE={rmse_soh:.5f}, MAE={mae_soh:.5f}')
    plt.plot(y_mcu_soh,  color='green', label=f'MCU: RMSE={rmse_mcu:.5f}, MAE={mae_mcu:.5f}')

    plt.xlabel("Time [days]",fontsize=16)
    plt.ylabel("SOH",fontsize=16)
    plt.tick_params(axis='both', labelsize=16)
    # plt.title(f"C{2*batt_id-1:02d}",fontsize=16)
    plt.legend(fontsize=16)
    plt.grid(True)
    plt.show()
