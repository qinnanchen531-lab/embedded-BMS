soh estimation excution sequence:
step1: feature_cal.py
	- Function: caculate the features every 3600s(1h) 
	- if you want to change the features, please change the output here (also change the feature_cols and target_cols)
step2: new_features.py:
	- the configuration of features and target(name and number) will be automatically changed (by calling feature_cal.py)
	- caculate the features (in s ->in h) and save the data in folder data/features_xxxx
	- scalers fitting
	- normalize features and save the data in folder data/featrues_xxxx_scaled
step3: train.py
	- train the neural network according to config.yaml
	- the network will be saved in xxxx.pth
step4: test_and_plot.py
	- test the trained neural  network and plot
	- get rmse and mae
	
step5: export_all.py
	- if the network is satisfying, output the files for embedded
	- copy and paste xxxx.onnx in related stm32 workplace
	


