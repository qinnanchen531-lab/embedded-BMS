
# below for offline window

import numpy as np
import torch
from torch.utils.data import Dataset
import numpy as np


class WindowBuilder:
    def __init__(self, features, target, window, stride):
        self.features = features
        self.target = target
        self.window = window
        self.stride = stride

    def build(self, df):
       
        X = df[self.features].values   # (N, F)
        Y = df[self.target].values     # (N,)

        N = len(df)
        X_list = []
        Y_list = []
        meta = []

        for start_idx in range(0, N - self.window + 1, self.stride):
            end_idx = start_idx + self.window

            X_win = X[start_idx:end_idx, :]
            Y_win = Y[end_idx - 1,:]

            X_list.append(X_win.astype(np.float32))
            Y_list.append(np.float32(Y_win))

            meta.append({
                "start_idx": start_idx,
                "end_idx": end_idx - 1
            })

        return X_list, Y_list, meta

class WindowDataset(Dataset):
    def __init__(self, X_list, Y_list):
        self.X = torch.from_numpy(np.array(X_list))   # (Nwin, W, F)
        self.Y = torch.from_numpy(np.array(Y_list))  # (Nwin, 1)

    def __len__(self):
        return len(self.X)
    
    def __getitem__(self, idx):
        return self.X[idx], self.Y[idx]
    
