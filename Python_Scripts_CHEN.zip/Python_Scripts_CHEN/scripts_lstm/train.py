# single output
import pandas as pd
from pathlib import Path
import matplotlib.pyplot as plt

from config_utils import load_config
from data_utils import WindowBuilder,WindowDataset
from model_def import LSTMModel

import torch
import torch.nn as nn #make weight and bias tensors
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import ReduceLROnPlateau

cfg=load_config()

#import raw data
SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent
DATA_DIR = ROOT_DIR / cfg["paths"]["data_dir"]
PARQUET_PATTERN = cfg["paths"]["parquet_pattern"]
nums=range(1,30,2)
filepaths=[]
for num in nums:
    path=DATA_DIR/PARQUET_PATTERN.format(num=num)
    filepaths.append(path)
    
def rmse(pred, target):
    return torch.sqrt(((pred - target) ** 2).mean())

builder=WindowBuilder(
    features=cfg["data"]["feature_cols"],
    target=cfg["data"]["target_col"],
    window=cfg["window"]["size"],
    stride=cfg["window"]["stride"]
)


#region data preparation
XTrain,YTrain=[],[]
XVal,YVal=[],[]


for n in range(15):
    batt_id=n+1

    if batt_id in cfg["split"]["idx_tr"]:
        continue

    df=pd.read_parquet(filepaths[n])

    X_list,Y_list,_=builder.build(df)

    if batt_id in cfg["split"]["idx_tr"]:
        XTrain+=X_list
        YTrain+=Y_list
    else:
        XVal+=X_list
        YVal+=Y_list
    
train_ds=WindowDataset(XTrain,YTrain)
val_ds=WindowDataset(XVal,YVal)


train_loader=DataLoader(train_ds,batch_size=cfg["train"]["batch_size"],shuffle=True)
val_loader=DataLoader(val_ds,batch_size=cfg["train"]["batch_size"],shuffle=False)   
#endregion

#region model preparation
model=LSTMModel()

criterion=nn.MSELoss()
optimizer=torch.optim.Adam(model.parameters(),lr=cfg["train"]["lr"])

#adjust the lr
scheduler=ReduceLROnPlateau(
    optimizer,
    mode='min',
    factor=0.5, #new_lr=old_lr*factor
    patience=15#how many epochs without improvement--then reducing lr
)
#endregion

#region start of training
train_losses, val_losses = [], []
train_rmses, val_rmses = [], []

plt.ion()  # 打开交互模式

fig, (ax1,ax2) = plt.subplots(2,1,figsize=(8,6),sharex=True)

best_val = float("inf")
bad_epochs=0
min_delta=cfg["train"]["min_delta"]
for epoch in range(cfg["train"]["max_epochs"]):
    model.train()
    epoch_loss=0.0
    epoch_rmse=0.0

    for Xb, Yb in train_loader:
        optimizer.zero_grad()
        
        Ypred,_=model(Xb)
        #输出由一个变两个之后推荐写法
        soh_pred=Ypred[:,0]
        # delta_pred=Ypred[:,1]
        soh_true=Yb[:,0]
        # delta_true=Yb[:,1]
        
        loss_soh=criterion(soh_pred,soh_true)
        # loss_delta=criterion(delta_pred, delta_true)
    
        loss=loss_soh
        #结束
        
        

        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), cfg["train"]["max_grad_norm"])
        optimizer.step()

        epoch_loss+=loss.item()*Xb.size(0)
        epoch_rmse+=rmse(Ypred,Yb).item()*Xb.size(0)
    epoch_loss/=len(train_loader.dataset)
    epoch_rmse/=len(train_loader.dataset)

    #validation
    model.eval()
    val_loss=0.0
    val_rmse=0.0
    with torch.no_grad():
        for Xb, Yb in val_loader:
            Ypred, _ = model(Xb)
            loss = criterion(Ypred, Yb)
            val_loss += loss.item()*Xb.size(0)
            val_rmse+=rmse(Ypred,Yb).item()*Xb.size(0)
    val_loss/=len(val_loader.dataset)
    val_rmse/=len(val_loader.dataset)
#endregion   
#region print and visualization
    print(f'Epoch [{epoch+1:3d}/{cfg["train"]["max_epochs"]}]'
          f"Train RMSE: {epoch_rmse:.6f} | "
          f"Val RMSE: {val_rmse:.6f}")
    
    #scheduler
    scheduler.step(val_rmse)

    # best checkpoint + early stopping
    if val_rmse < best_val-min_delta:
        best_val=val_rmse
        bad_epochs=0
        torch.save(model.state_dict(), "best_lstm_model_1h.pth")
        print(f"✅ Saved best model at epoch {epoch+1}, val_rmse={val_rmse:.5f}")
    else:
        bad_epochs+=1
        print(f'⚠️ No improvement. bad_epochs = {bad_epochs}/{cfg["train"]["patience"]}')
    if bad_epochs>cfg["train"]["patience"]:
        print(f"🛑 Early stopping at epoch {epoch+1}")
        break

    train_losses.append(epoch_loss)
    train_rmses.append(epoch_rmse)
    val_losses.append(val_loss)
    val_rmses.append(val_rmse)
    
    
    
    
    # ===== 动态绘图 =====
    ax1.clear()
    ax1.plot(train_rmses, 'b-', label='Train RMSE')
    ax1.plot(val_rmses, 'r--', label='Val RMSE')
    ax1.set_ylabel('RMSE')
    # ax1.set_title('Training Progress')
    ax1.legend()
    ax1.grid(True)

    ax2.clear()
    ax2.plot(train_losses, 'b-', label='Train MAE')
    ax2.plot(val_losses, 'r--', label='Val MAE')
    ax2.set_xlabel('Epoch')
    ax2.set_ylabel('MAE')
    ax2.legend()
    ax2.grid(True)

    plt.pause(0.01)  # 刷新图
    
plt.ioff()
plt.show()
#endregion
