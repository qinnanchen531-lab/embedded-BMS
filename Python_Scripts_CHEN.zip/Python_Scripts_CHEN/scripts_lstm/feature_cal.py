import math
from numba import njit

@njit
def _add_sample_core(
    temp, volt, curr,efc_k,
    curr_threshold,
    n,
    temp_mean, temp_M2,
    volt_mean, volt_M2,
    curr_sum, curr_sq_sum,
    prev_sign,
    switch_count_window,
    switch_count_total,
    efc_total,
    efc_max,
    energy_window,
    energy_throughput,
    dV_prev,dI_prev,
    R_sum,R_count
):
    # -------- EFC --------
    delta_efc = abs(curr) * efc_k
    efc_total += delta_efc
    if efc_total > efc_max:
        efc_max = efc_total

    # -------- Temp (Welford) --------
    n += 1
    delta_temp = temp - temp_mean
    temp_mean += delta_temp / n
    temp_M2 += delta_temp * (temp - temp_mean)

    # -------- Volt --------
    delta_volt = volt - volt_mean
    volt_mean += delta_volt / n
    volt_M2 += delta_volt * (volt - volt_mean)

    # -------- Curr --------
    curr_sum += abs(curr)
    curr_sq_sum += curr * curr
    

    #---------Energy----------
    energy_window +=volt*curr
    energy_throughput+=volt*abs(curr)

    #---------内阻估计----------
    R_inst=0.0
    EPS = 1e-8 # avoid 0 division
    if dI_prev !=0.0 or curr !=dI_prev:
        delta_I=curr-dI_prev
        if abs(delta_I)>EPS:
            R_inst=abs((volt-dV_prev)/(curr-dI_prev))
            R_sum+=R_inst
            R_count+=1

    # -------- Sign --------
    if curr > curr_threshold:
        sign = 1
    elif curr < -curr_threshold:
        sign = -1
    else:
        sign = 0

    if prev_sign != 0 and sign != 0 and sign != prev_sign:
        switch_count_window += 1
        switch_count_total += 1

    if sign != 0:
        prev_sign = sign

    return (
        n,
        temp_mean, temp_M2,
        volt_mean, volt_M2,
        curr_sum, curr_sq_sum,
        prev_sign,
        switch_count_window,
        switch_count_total,
        efc_total,
        efc_max,
        energy_window,
        energy_throughput,
        R_sum,
        R_count
    )

class FeatureExtractor:
    feature_cols = [
        "Temp_mean", "Temp_std",
        #"Volt_mean", 
        "Volt_std",
        "Curr_abs_mean", "Curr_rms",
        "EFC_delta", "EFC_max",
        #"Energy_window",
        "Energy_cumulative","Energy_throughput",
        "R_mean"
        #"Curr_switch_count", 
        #"Curr_switch_total"
    ]
    def __init__(self, window_size):
        self.dt = 1.0
        self.capacity = 1.8
        self.window_size = window_size
        self.curr_threshold = 0.05

        # 计数
        self.n = 0
        self.window_counter = 0

        # 温度增量统计 (Welford)
        self.temp_mean = 0.0
        self.temp_M2 = 0.0

        # 电压增量统计 (Welford)
        self.volt_mean = 0.0
        self.volt_M2 = 0.0

        # 电流 RMS / 平均
        self.curr_sum = 0.0
        self.curr_sq_sum = 0.0

        # 能量
        self.energy_window=0.0
        self.cumulative_energy=0.0
        self.energy_throughput=0.0

        #内阻估计
        self.dV_prev=0.0
        self.dI_prev=0.0
        self.R_sum=0.0
        self.R_count=0

        # 电流方向切换
        self.prev_sign = 0
        self.switch_count_window = 0
        self.switch_count_total = 0

        # EFC
        self.efc_k = self.dt/(self.capacity * self.window_size)
        self.efc_total = 0.0
        self.efc_window_start = 0.0
        self.efc_max = 0.0
    
    @classmethod
    def get_feature_cols(cls):
        return cls.feature_cols

    def add_sample(self, temp, volt, curr):
            
        (
            self.n,
            self.temp_mean, self.temp_M2,
            self.volt_mean, self.volt_M2,
            self.curr_sum, self.curr_sq_sum,
            self.prev_sign,
            self.switch_count_window,
            self.switch_count_total,
            self.efc_total,
            self.efc_max,
            self.energy_window,self.energy_throughput,
            self.R_sum,
            self.R_count
        ) = _add_sample_core(
            temp, volt, curr,
            self.efc_k,
            self.curr_threshold,
            self.n,
            self.temp_mean, self.temp_M2,
            self.volt_mean, self.volt_M2,
            self.curr_sum, self.curr_sq_sum,
            self.prev_sign,
            self.switch_count_window,
            self.switch_count_total,
            self.efc_total,
            self.efc_max,
            self.energy_window,self.energy_throughput,
            self.dV_prev,self.dI_prev,
            self.R_sum,self.R_count
        )
        # ----------------- 更新上一次的电压和电流
        self.dV_prev=volt
        self.dI_prev=curr
        # ----------------- 更新窗口计数 -----------------
        
        self.window_counter += 1
        

    def is_ready(self):
        return self.window_counter >= self.window_size

    def compute_features(self):
    
        # Temp
        Temp_mean = self.temp_mean
        Temp_std = math.sqrt(self.temp_M2 / max(1, self.n))

        # Volt
        Volt_mean = self.volt_mean
        Volt_std = math.sqrt(self.volt_M2 / max(1, self.n))

        # Curr
        Curr_mean = self.curr_sum / max(1, self.n)
        Curr_rms = math.sqrt(self.curr_sq_sum / max(1, self.n))

        # EFC
        EFC_delta = self.efc_total - self.efc_window_start
        EFC_max = self.efc_max

        # Energy
        Window_energy=self.energy_window/3600 # in Wh
        self.cumulative_energy+=Window_energy
        Cumulative_energy=self.cumulative_energy
        Throughput_energy=self.energy_throughput/3600


        #内阻
        R_mean=self.R_sum/max(1,self.R_count) if self.R_count>0 else 0.0

        # Curr switch
        # Curr_switch_count = self.switch_count_window
        # Curr_switch_total = self.switch_count_total

        return (Temp_mean, Temp_std, 
                #Volt_mean, 
                Volt_std, 
                Curr_mean,Curr_rms,
                EFC_delta,EFC_max,
                #Window_energy,
                Cumulative_energy,Throughput_energy,
                R_mean
                #Curr_switch_count,
                #Curr_switch_total
        )

    def reset_window(self):
        self.window_counter = 0
        self.n=0
        self.switch_count_window = 0
        self.efc_window_start = self.efc_total
        self.n = 0               # 重置窗口内样本计数
        self.temp_mean = 0.0
        self.temp_M2 = 0.0
        self.volt_mean = 0.0
        self.volt_M2 = 0.0
        self.curr_sum = 0.0
        self.curr_sq_sum = 0.0
        self.energy_window = 0.0
        self.energy_throughput=0.0
        self.R_sum = 0.0
        self.R_count = 0
        self.dV_prev = 0.0
        self.dI_prev = 0.0
        self.prev_sign = 0

class TargetExtractor:
    target_cols=['SOH']
    def __init__(self):
        self.soh_first = 1.0
        self.last_soh = 0.0
    
    @classmethod
    def get_target_cols(cls):
        return cls.target_cols
    def add_sample(self, soh):
        self.last_soh = soh

    def compute_target(self):
        dsoh = self.last_soh - self.soh_first
        return self.last_soh,dsoh

    def reset_window(self):
        self.soh_first = self.last_soh
        self.last_soh = None

