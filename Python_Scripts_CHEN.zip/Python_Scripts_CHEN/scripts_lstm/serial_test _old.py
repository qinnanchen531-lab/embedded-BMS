import os
import struct
import numpy as np
import pandas as pd
import serial
import matplotlib.pyplot as plt
import struct
import time

# region test 
nums = np.arange(1, 30, 2)

this_file = os.path.abspath(__file__)
this_dir = os.path.dirname(this_file)
parent1 = os.path.dirname(this_dir)
parent2 = os.path.dirname(parent1)

filepath = []

for num in nums:
    path = os.path.join(
        parent1,
        "data",
        "rawdata",
        "MGFarm_18650_FE",
        f"df_FE_C{num:02d}.parquet"
    )
    filepath.append(path)
save_dir = os.path.join(parent1, "data", "mcu_soh")
os.makedirs(save_dir, exist_ok=True)
save_path = os.path.join(save_dir, "mcu_soh_C29.parquet")


df = pd.read_parquet(filepath[14])
I = df["Current[A]"].to_numpy()
U = df["Voltage[V]"].to_numpy()
T = df["Temperature[°C]"].to_numpy()
SoH=df["SOH"].to_numpy()
pack=60

start_idx=0


sum=(len(I)-start_idx)//pack




ser = globals().get('ser', None)

if ser is not None:
    ser.close()

ser = serial.Serial(
    port="COM4",
    baudrate=115200,
    timeout=5
)

ser.reset_input_buffer()
ser.reset_output_buffer()

SoH_lstm=np.full(sum, np.nan)
SoH_GT=np.full(sum, np.nan)

# plt.ion()
# fig, ax = plt.subplots()
# line, = ax.plot([], [], '-o')
# ax.set_xlabel("Time Step[s]")
# ax.set_ylabel("SOH [%]")
# ax.grid(True)

# x_data = []
# y_data = []
header = bytes([0xAA, 0x55])
packer = struct.Struct('fff')
unpacker = struct.Struct('<I')
rx_buffer = bytearray()

for k in range(sum):
    idx=start_idx+k*pack
    # ---------- pack ----------
    payload = packer.pack(I[idx], U[idx], T[idx])
    ser.write(header + payload)

    rx_buffer += ser.read_all()
    while len(rx_buffer) >= 6:
        frame = rx_buffer[:6]
        rx_buffer = rx_buffer[6:]

        if frame[0] == 0xAA and frame[1] == 0x55:
            received = unpacker.unpack(frame[2:6])[0]

            if received == 65535:
                SoH_lstm[k] = np.nan
            else:
                SoH_lstm[k] = received 
        else:
            SoH_lstm[k] = np.nan
        
        SoH_GT[k] = SoH[idx]
    
    # ---------- plotting----------
    if k % (3600//pack) == 0:
        progress = (k + 1) / len(I) * 100* (3600//pack)
        print(f"\rProgress: {progress:6.2f}% | {k// (3600//pack)} hours done | SoH={SoH_lstm[k]:.2f}", end='')
    # x_data.append(k/3600)  # 转换为小时
    # y_data.append(SoH_lstm[k])

    # line.set_xdata(x_data)
    # line.set_ydata(y_data)

    # ax.relim()
    # ax.autoscale_view()

    # plt.pause(0.001)
         

    




# ---------------------------
# 7. end
# ---------------------------
ser.close()
#plt.ioff()
#plt.show()

plt.figure(figsize=(12, 5))

plt.plot(SoH_lstm[~np.isnan(SoH_lstm)])

plt.xlabel("Time Step[min]",fontsize=16)

plt.ylabel("Number of Cycles",fontsize=16)
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.grid(True)
plt.show()    




# df_soh = pd.DataFrame({
#     "SoH_lstm": SoH_lstm,
#     "SoH_GT": SoH_GT
# })


# df_soh.to_parquet(save_path, index=False)
# print(f"Saved to: {save_path}")


# error = SoH_lstm -SoH_GT

# mae = np.mean(np.abs(error))
# rmse = np.sqrt(np.mean(error ** 2))

# # print(f"MAE  = {mae:.6f}")
# # print(f"RMSE = {rmse:.6f}")



# plt.figure(figsize=(10, 5))

# plt.plot(SoH_GT, label="Ground Truth SoH")
# plt.plot(SoH_lstm, label="LSTM SoH")
# plt.title(f"SoH Comparison | MAE={mae:.5f}, RMSE={rmse:.5f}")
# plt.xlabel("Cycle / Sample Index")
# plt.ylabel("SoH")
# plt.legend()
# plt.grid(True)

# plt.show()
#------------------------------------------


df_soh = pd.read_parquet(os.path.join(save_dir, "mcu_soh_C13.parquet"))


idx=list(range(168*60, len(df_soh), 24*60))


SoH_lstm=df_soh["SoH_lstm"].iloc[idx].reset_index(drop=True)
SoH_GT=df_soh["SoH_GT"].iloc[idx].reset_index(drop=True)

error = np.array(SoH_lstm) - np.array(SoH_GT)

mae = np.mean(np.abs(error))
rmse = np.sqrt(np.mean(error ** 2))

plt.figure(figsize=(10, 5))

plt.plot(SoH_GT, label="Ground Truth")
plt.plot(SoH_lstm, label="LSTM SoH")

plt.title(f"SoH Comparison | MAE={mae:.5f}, RMSE={rmse:.5f}")
plt.xlabel("Cycle / Sample Index")
plt.ylabel("SoH")
plt.legend()
plt.grid(True)

plt.show()


