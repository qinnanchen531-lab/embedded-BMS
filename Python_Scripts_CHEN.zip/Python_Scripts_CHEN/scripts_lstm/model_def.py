import torch
import torch.nn as nn #make weight and bias tensors
from config_utils import load_config

class LSTMModel(nn.Module):
    cfg=load_config()
    def __init__(self,
                 input_size=cfg["model"]["input_size"],
                 rnn_unit=cfg["model"]["rnn_unit"],
                 lstm_layers=cfg["model"]["lstm_layers"],
                 dropout=cfg["model"]["dropout"],
                 output_size=cfg["model"]["output_size"]):
        super(LSTMModel,self).__init__()
        self.input_fc=nn.Linear(input_size,rnn_unit)
        self.lstm=nn.LSTM(input_size=rnn_unit,hidden_size=rnn_unit,
                          num_layers=lstm_layers,batch_first=True) 
        self.dropout=nn.Dropout(dropout)
        self.output_fc=nn.Linear(rnn_unit,output_size)
    
    def forward(self,x,hidden=None):
        x=self.input_fc(x)
        if hidden is None:
            out,(hn,cn)=self.lstm(x)
        else:
            out,(hn,cn)=self.lstm(x,hidden)

        last_out=out[:,-1,:]
        last_out=self.dropout(last_out)
        y=self.output_fc(last_out)
        return y,(hn,cn)