from model_def import LSTMModel
import torch
import torch.nn as nn 
import numpy as np
import os
from config_utils import load_config

cfg=load_config()

WINDOW =cfg["window"]["size"]
NUM_FEATURES = cfg["model"]["input_size"]

PT_PATH     = "soh_model_fp32.pt"
ONNX_PATH   = "soh_model.onnx"
NPZ_PATH    = "soh_model_weights.npz"
TF_DIR      = "soh_tf"
TFLITE_PATH = "soh_model_int8.tflite"

def export_all(model):
    model.eval()
    torch.save({
        "model_state": model.state_dict(),
        "model_config": {
            "window": WINDOW,
            "num_features": NUM_FEATURES,
            "model_class": model.__class__.__name__,
        }
    }, PT_PATH)
    print(f"[OK] Saved {PT_PATH}")

    # -----------------------
    # 2. ONNX
    # -----------------------
    dummy_input = torch.randn(1, WINDOW, NUM_FEATURES)
    torch.onnx.export(
        model,
        dummy_input,
        ONNX_PATH,
        input_names=["input"],
        output_names=["output"],
        dynamic_axes={"input": {0: "batch"}, "output": {0: "batch"}},
        opset_version=13
    )
    print(f"[OK] Saved {ONNX_PATH}")

    # -----------------------
    # 3. NPZ
    # -----------------------
    state = model.state_dict()
    np.savez(NPZ_PATH, **{k: v.cpu().numpy() for k, v in state.items()})
    print(f"[OK] Saved {NPZ_PATH}")
    print("    Keys:", list(state.keys()))

    # -----------------------
    # 4. TFLite int8
    # -----------------------
    try:
        import tensorflow as tf

      
        if not os.path.exists(TF_DIR):
            print("[INFO] Converting ONNX -> TensorFlow SavedModel...")
            os.system(f"onnx-tf convert -i {ONNX_PATH} -o {TF_DIR}")

        converter = tf.lite.TFLiteConverter.from_saved_model(TF_DIR)
        converter.optimizations = [tf.lite.Optimize.DEFAULT]

        def representative_dataset():
            for _ in range(200):
                x = np.random.randn(1, WINDOW, NUM_FEATURES).astype(np.float32)
                yield [x]

        converter.representative_dataset = representative_dataset
        converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
        converter.inference_input_type = tf.int8
        converter.inference_output_type = tf.int8

        tflite_model = converter.convert()

        with open(TFLITE_PATH, "wb") as f:
            f.write(tflite_model)
        print(f"[OK] Saved {TFLITE_PATH}")

    except Exception as e:
        print("[WARN] TFLite int8 export failed:")
        print(e)
        print("You can manually run ONNX -> TF -> TFLite later.")


if __name__ == "__main__":
    model = LSTMModel()
    ckpt = torch.load("best_lstm_model_1h.pth", map_location="cpu")
    model.load_state_dict(ckpt)
    
    export_all(model)



