import numpy as np
import matplotlib.pyplot as plt
from config_utils import load_config
from pathlib import Path
import pandas as pd

cfg=load_config()
SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent
DATA_DIR = ROOT_DIR / cfg["paths"]["data_dir"]
PARQUET_PATTERN = cfg["paths"]["parquet_pattern"]
nums=range(1,30,2)
filepaths=[]
for num in nums:
    path=DATA_DIR/PARQUET_PATTERN.format(num=num)
    filepaths.append(path)

# DATASET SPLIT BEGIN
battery_info = {
    "C01": [0.5, 1, 45],
    "C03": [0.5, 1, 65],
    "C05": [0.9, 1, 45],
    "C07": [0.9, 1, 65],
    "C09": [0.5, 2.5, 45],
    "C11": [0.5, 2.5, 65],
    "C13": [0.9, 2.5, 45],
    "C15": [0.9, 2.5, 65],
    "C17": [0.7, 1.75, 55],
    "C19": [0.7, 1.75, 38],
    "C21": [0.7, 1.75, 71],
    "C23": [0.3, 1.75, 55],
    "C25": [1.0, 1.75, 55],
    "C27": [0.7, 0.5, 55],
    "C29": [0.7, 3.0, 55],
}
plt.figure(figsize=(15,8))
# gs=fig.add_gridspec(1,2,width_ratios=[3,1])

# ax = fig.add_subplot(gs[0, 0])
# ax_table = fig.add_subplot(gs[0, 1])

for batt_id in cfg["split"]["idx_tr"]:
    df=pd.read_parquet(filepaths[batt_id-1])
    plt.plot(df['SOH'], label=f"C{batt_id:02d}", color='blue')
for batt_id in cfg["split"]["idx_te"]:
    df=pd.read_parquet(filepaths[batt_id-1])
    plt.plot(df['SOH'], label=f"C{batt_id:02d}", color='orange')
for batt_id in cfg["split"]["idx_va"]:
    df=pd.read_parquet(filepaths[batt_id-1])
    plt.plot(df['SOH'], label=f"C{batt_id:02d}", color='green')

from matplotlib.lines import Line2D
legend_elements = [
    Line2D([0], [0], color='blue', lw=2, label='Training Set'),
    Line2D([0], [0], color='orange', lw=2, label='Test Set'),
    Line2D([0], [0], color='green', lw=2, label='Validation Set')
]

plt.xlabel("Time [h]", fontsize=16)
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.ylabel("SOH", fontsize=16)
plt.grid(True)
plt.legend(handles=legend_elements,loc="upper right",fontsize=16)

# ax_table.axis('off')
# col_labels=["Battery ID", "Charge Rate [C]", "Discharge Rate [C]", "DoD[%]"]
# table_data=[[k, v[0], v[1], v[2]] for k, v in battery_info.items()]
# table = ax_table.table(
#     cellText=table_data,
#     colLabels=col_labels,
#     loc="center",
#     cellLoc="center"
# )
# table.auto_set_font_size(False)
# table.set_fontsize(10)
# table.scale(1, 1.3)

plt.tight_layout()
plt.show()
#DATASET SPLIT END



# region LSTM MODEL
# 2 KINDS OF SCALER
# -----------------------------

# batteries = [4, 6, 8, 10, 11, 12, 15]
# # batteries = [1,2,3,5,7,9,13,14] #training set


# # test and validation
# rmse_A = np.array([0.010492, 0.044880, 0.075581, 0.013893, 0.024117, 0.034974, 0.114548])
# mae_A  = np.array([0.006668, 0.032059, 0.067913, 0.011313, 0.020940, 0.025562, 0.093469])

# rmse_B = np.array([0.012412, 0.021778, 0.047329, 0.031492, 0.031819, 0.025515, 0.049126])
# mae_B  = np.array([0.011260, 0.015825, 0.036923, 0.026089, 0.022210, 0.017553, 0.037466])


# # #training Dataset
# # rmse_A = np.array([0.008125, 0.011390, 0.013522, 0.059706, 0.111591, 0.059500, 0.077963, 0.011915])
# # mae_A  = np.array([0.005972, 0.008492, 0.010765, 0.049853, 0.093941, 0.051566, 0.066213, 0.009098])

# # rmse_B = np.array([0.008209, 0.014915, 0.008067, 0.029407, 0.040044, 0.019989, 0.021544, 0.014857])
# # mae_B  = np.array([0.007499, 0.013474, 0.006454, 0.026573, 0.026853, 0.016096, 0.016439, 0.013106])


# # -----------------------------

# mean_rmse_A = np.mean(rmse_A)
# std_rmse_A  = np.std(rmse_A)

# mean_mae_A  = np.mean(mae_A)
# std_mae_A   = np.std(mae_A)

# mean_rmse_B = np.mean(rmse_B)
# std_rmse_B  = np.std(rmse_B)

# mean_mae_B  = np.mean(mae_B)
# std_mae_B   = np.std(mae_B)

# # -----------------------------
# # error bar plot
# labels = ['RMSE', 'MAE']
# x = np.arange(len(labels))
# width = 0.35  # width of the bars

# # means and stds for both schemes
# means_A = [mean_rmse_A, mean_mae_A]
# stds_A  = [std_rmse_A, std_mae_A]

# means_B = [mean_rmse_B, mean_mae_B]
# stds_B  = [std_rmse_B, std_mae_B]

# plt.figure(figsize=(8,5))

# # plot bars with error bars
# plt.bar(x - width/2, means_A, width, yerr=stds_A, capsize=5, label='Scheme A', color='blue')
# plt.bar(x + width/2, means_B, width, yerr=stds_B, capsize=5, label='Scheme B', color='orange')

# # -----------------------------

# plt.xticks(x, labels, fontsize=16)
# plt.ylabel('Error',fontsize=16)
# plt.yticks(fontsize=16)
# # plt.title('Comparison of RMSE and MAE Across 7 Batteries')
# plt.legend(fontsize=16)
# plt.grid(axis='y', linestyle='--', alpha=0.5)
# plt.tight_layout()
# plt.show()

# # -----------------------------
# # line plot
# plt.figure(figsize=(10, 6))

# # scheme A (color blue)
# plt.plot(batteries, rmse_A, color='blue', linestyle='-', marker='o', label='Scheme A RMSE')
# plt.plot(batteries, mae_A,  color='blue', linestyle='--', marker='s', label='Scheme A MAE')

# # scheme B (color orange)
# plt.plot(batteries, rmse_B, color='orange', linestyle='-', marker='o', label='Scheme B RMSE')
# plt.plot(batteries, mae_B,  color='orange', linestyle='--', marker='s', label='Scheme B MAE')

# # -----------------------------

# plt.xlabel('Battery ID')
# plt.ylabel('Error')
# # plt.title('Comparison of RMSE and MAE Across Batteries')
# plt.xticks(batteries)  
# plt.grid(True, linestyle='--', alpha=0.5)
# plt.legend()
# plt.tight_layout()
# plt.show()
# endregion LSTM MODEL


# region LSTM MODEL RESULTS 2
# # Compare python and mcu
# # -----------------------------

# # batteries = [4, 6, 8, 10, 11, 12, 15]
# batteries = [1,2,3,5,7,9,13,14] #training set


# # # test and validation
# # rmse_mcu = np.array([0.020638, 0.035240, 0.040459, 0.038556, 0.044920, 0.022465, 0.062589])
# # mae_mcu  = np.array([0.017904, 0.027217, 0.027936, 0.032049, 0.035178, 0.013223, 0.048901])

# # rmse_py = np.array([0.012412, 0.021778, 0.047329, 0.031492, 0.031819, 0.025515, 0.049126])
# # mae_py  = np.array([0.011260, 0.015825, 0.036923, 0.026089, 0.022210, 0.017553, 0.037466])


# #training Dataset
# rmse_mcu = np.array([0.020585, 0.024899, 0.011628, 0.031936, 0.078570, 0.016257, 0.047741, 0.018279])
# mae_mcu  = np.array([0.018002, 0.022114, 0.009104, 0.027122, 0.056319, 0.012768, 0.038194, 0.016657])

# rmse_py = np.array([0.008209, 0.014915, 0.008067, 0.029407, 0.040044, 0.019989, 0.021544, 0.014857])
# mae_py  = np.array([0.007499, 0.013474, 0.006454, 0.026573, 0.026853, 0.016096, 0.016439, 0.013106])


# # -----------------------------

# mean_rmse_mcu = np.mean(rmse_mcu)
# std_rmse_mcu  = np.std(rmse_mcu)

# mean_mae_mcu  = np.mean(mae_mcu)
# std_mae_mcu   = np.std(mae_mcu)

# mean_rmse_py = np.mean(rmse_py)
# std_rmse_py  = np.std(rmse_py)

# mean_mae_py  = np.mean(mae_py)
# std_mae_py   = np.std(mae_py)

# # -----------------------------

# labels = ['RMSE', 'MAE']
# x = np.arange(len(labels))
# width = 0.35  


# means_mcu = [mean_rmse_mcu, mean_mae_mcu]
# stds_mcu  = [std_rmse_mcu, std_mae_mcu]

# means_py = [mean_rmse_py, mean_mae_py]
# stds_py  = [std_rmse_py, std_mae_py]

# plt.figure(figsize=(8,5))


# plt.bar(x - width/2, means_mcu, width, yerr=stds_mcu, capsize=5, label='MCU', color='blue')
# plt.bar(x + width/2, means_py, width, yerr=stds_py, capsize=5, label='PC', color='orange')

# # -----------------------------
# plt.xticks(x, labels, fontsize=16)
# plt.ylabel('Error',fontsize=16)
# plt.yticks(fontsize=16)
# # plt.title('Comparison of RMSE and MAE Across 7 Batteries')
# plt.legend(fontsize=16)
# plt.grid(axis='y', linestyle='--', alpha=0.5)
# plt.tight_layout()
# plt.show()



# -----------------------------

# plt.figure(figsize=(10, 6))


# plt.plot(batteries, rmse_mcu, color='blue', linestyle='-', marker='o', label='MCU RMSE')
# plt.plot(batteries, mae_mcu,  color='blue', linestyle='--', marker='s', label='MCU MAE')


# plt.plot(batteries, rmse_py, color='orange', linestyle='-', marker='o', label='PC RMSE')
# plt.plot(batteries, mae_py,  color='orange', linestyle='--', marker='s', label='PC MAE')

# -----------------------------

# plt.xlabel('Cell ID', fontsize=16)
# plt.ylabel('Error', fontsize=16)
# # plt.title('Comparison of RMSE and MAE Across Batteries')
# plt.xticks(batteries, fontsize=16)
# plt.yticks(fontsize=16)
# plt.grid(True, linestyle='--', alpha=0.5)
# plt.legend(fontsize=16)
# plt.tight_layout()
# plt.show()
# endregion LSTM MODEL RESULTS 2