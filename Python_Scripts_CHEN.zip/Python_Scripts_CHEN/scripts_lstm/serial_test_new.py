import os
import struct
import numpy as np
import pandas as pd
import serial
import matplotlib.pyplot as plt
import time

# ======================================
# 数据读取
# ======================================

nums = np.arange(1,30,2)

this_file = os.path.abspath(__file__)
this_dir = os.path.dirname(this_file)
parent1 = os.path.dirname(this_dir)

filepath=[]

for num in nums:

    path=os.path.join(
        parent1,
        "data",
        "rawdata",
        "MGFarm_18650_FE",
        f"df_FE_C{num:02d}.parquet"
    )

    filepath.append(path)

save_dir=os.path.join(
    parent1,
    "data",
    "mcu_soh"
)

os.makedirs(
    save_dir,
    exist_ok=True
)

save_path=os.path.join(
    save_dir,
    "mcu_soh_C29.parquet"
)

df=pd.read_parquet(filepath[14])

I=df["Current[A]"].to_numpy()
U=df["Voltage[V]"].to_numpy()
T=df["Temperature[°C]"].to_numpy()
SoH=df["SOH"].to_numpy()

pack=60
start_idx=0

total_samples=(len(I)-start_idx)//pack

# ======================================
# set up serial communication
# ======================================

ser=globals().get("ser",None)

if ser is not None:
    ser.close()

ser=serial.Serial(
    port="COM4",
    baudrate=115200,
    timeout=0.1
)

ser.reset_input_buffer()
ser.reset_output_buffer()

# ======================================
# communication protocol
# ======================================

header=b'\xAA\x55'
tx_packer=struct.Struct('<fff')
rx_unpacker=struct.Struct('<I')
SoH_lstm=np.full(total_samples,np.nan)
SoH_GT=np.full(total_samples,np.nan)

# ======================================
# receive function with auto-resynchronization
# ======================================

def receive_frame():
    frame=ser.read(6)
    if len(frame)!=6:
        return None
    # resynchronize if header is not found
    while frame[:2]!=header:
        next_byte=ser.read(1)
        if len(next_byte)==0:
            return None
        frame=frame[1:]+next_byte
    value=rx_unpacker.unpack(
        frame[2:]
    )[0]

    return value


# ======================================
# main loop
# ======================================

start=time.time()

for k in range(total_samples):

    idx=start_idx+k*pack
    # ----------------
    # form payload
    # ----------------
    payload=tx_packer.pack(I[idx],U[idx],T[idx])
    ser.write(header+payload)
    # ----------------
    # receive response
    # ----------------
    received=receive_frame()

    if received is None:
        SoH_lstm[k]=np.nan
    elif received==65535:
        SoH_lstm[k]=np.nan
    else:
        SoH_lstm[k]=received
    SoH_GT[k]=SoH[idx]

    # ----------------
    # progress display
    # ----------------

    if k%(3600//pack)==0:
        progress=(k+1)/total_samples*100
        print(
            f"\r"
            f"Progress:"
            f"{progress:6.2f}% "
            f"| {k//(3600//pack)}h "
            f"| SoH="
            f"{SoH_lstm[k]:.4f}",
            end=""
        )
ser.close()

elapsed=time.time()-start

print()
print(f"\nDone in {elapsed:.2f}s")

# ======================================
# save results
# ======================================

df_soh=pd.DataFrame({"SoH_lstm":SoH_lstm,"SoH_GT":SoH_GT})
df_soh.to_parquet(save_path,index=False)
print(f"Saved:\n{save_path}")

# ======================================
# evaluation
# ======================================

valid=~np.isnan(SoH_lstm)
error=(SoH_lstm[valid]-SoH_GT[valid])
mae=np.mean(np.abs(error))
rmse=np.sqrt(np.mean(error**2))
print(f"MAE={mae:.6f}")
print(f"RMSE={rmse:.6f}")

# ======================================
# plotting
# ======================================

plt.rcParams["font.family"]="Times New Roman"
plt.rcParams["font.size"]=16

plt.figure(figsize=(12,5))
plt.plot(SoH_GT,label="Ground Truth")
plt.plot(SoH_lstm,label="MCU LSTM")
plt.xlabel("Time Step")
plt.ylabel("SOH")
plt.title(f"MAE={mae:.5f}, RMSE={rmse:.5f}")

plt.xticks(fontsize=16)
plt.yticks(fontsize=16)

plt.grid(True)
plt.legend()

plt.show()
print('done')