# feature extraction and scaling for 1h features
# fit scalers on training set
# export scaler params to C header file for MCU implementation
import pandas as pd
import numpy as np
from pathlib import Path
import joblib
from sklearn.preprocessing import  RobustScaler,StandardScaler,MinMaxScaler
import yaml
from feature_cal import FeatureExtractor,TargetExtractor
from config_utils import load_config

def export_scaler_to_c(feat_scalers, targ_scaler, feature_cols, filename="scaler_params.h"):
   
    with open(filename, "w") as f:
        f.write("#ifndef SCALER_PARAMS_H\n")
        f.write("#define SCALER_PARAMS_H\n\n")

        f.write(f"#define NUM_FEATURES {len(feature_cols)}\n\n")

        # a coifficients
        f.write("static const float feature_a[NUM_FEATURES] = {\n")
        for col in feature_cols:
            scaler = feat_scalers[col]

            if isinstance(scaler, StandardScaler):
                a = 1.0 / scaler.scale_[0]

            elif isinstance(scaler, RobustScaler):
                a = 1.0 / scaler.scale_[0]

            elif isinstance(scaler, MinMaxScaler):
                a = 1.0 / scaler.data_range_[0]

            else:
                raise ValueError(f"Unknown scaler for {col}")

            f.write(f"    {a:.8f}f,\n")
        f.write("};\n\n")

        # b coifficients
        f.write("static const float feature_b[NUM_FEATURES] = {\n")
        for col in feature_cols:
            scaler = feat_scalers[col]

            if isinstance(scaler, StandardScaler):
                b = -scaler.mean_[0] / scaler.scale_[0]

            elif isinstance(scaler, RobustScaler):
                b = -scaler.center_[0] / scaler.scale_[0]

            elif isinstance(scaler, MinMaxScaler):
                b = -scaler.data_min_[0] / scaler.data_range_[0]

            else:
                raise ValueError(f"Unknown scaler for {col}")

            f.write(f"    {b:.8f}f,\n")
        f.write("};\n\n")

        # target scaler（StandardScaler）
        f.write(f"#define NUM_TARGETS {len(target_cols)}\n\n")
        f.write("static const float target_a[NUM_TARGETS] = {\n")
        for col in target_cols:
            scaler = targ_scaler[col]
            if hasattr(scaler, "scale_"):
                a = 1.0 / scaler.scale_[0]
            elif hasattr(scaler, "data_range_"):
                a = 1.0 / scaler.data_range_[0]
            else:
                raise ValueError(f"Unknown scaler for target {col}")
            f.write(f"    {a:.8f}f,\n")
        f.write("};\n\n")


        f.write("static const float target_b[NUM_TARGETS] = {\n")
        for col in target_cols:
            scaler = targ_scaler[col]
            if hasattr(scaler, "mean_"):
                b = -scaler.mean_[0] / scaler.scale_[0]
            elif hasattr(scaler, "center_"):
                b = -scaler.center_[0] / scaler.scale_[0]
            elif hasattr(scaler, "data_min_"):
                b = -scaler.data_min_[0] / scaler.data_range_[0]
            else:
                raise ValueError(f"Unknown scaler for target {col}")
            f.write(f"    {b:.8f}f,\n")
        f.write("};\n\n")
        f.write("#endif\n")
#C code：
# float scale_feature(float x, int i)
# {
#     return feature_a[i] * x + feature_b[i];
# }
def scale_one_feature(val,scaler):
    if hasattr(scaler, "data_min_"):  # MinMaxScaler
        return (val - scaler.data_min_[0]) / scaler.data_range_[0]

    elif hasattr(scaler, "center_"):  # Standard / Robust
        return (val - scaler.center_[0]) / scaler.scale_[0]
    elif hasattr(scaler, "mean_"):
        return (val - scaler.mean_[0]) / scaler.scale_[0]
    else:
        raise ValueError("Unknown scaler type")
cfg=load_config()
idx_tr=cfg["split"]["idx_tr"]
idx_te=cfg["split"]["idx_te"]
idx_va=cfg["split"]["idx_va"]

#import raw data
SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent
DATA_DIR = ROOT_DIR / "data"
nums=range(1,30,2)
filepaths=[]
for num in nums:
    path=(
        DATA_DIR
        /"rawdata"
        /"MGFarm_18650_FE"
        /f"df_FE_C{num:02d}.parquet"
    )
    filepaths.append(path)



WINDOW_SIZE=3600*cfg["window"]["filter"]

feature_cols=FeatureExtractor.get_feature_cols()
target_cols=TargetExtractor.get_target_cols()

print("FeatureExtractor columns:",feature_cols)
print("TargetExtractor columns :", target_cols)

#write to config.yaml
with open("config.yaml", "r") as f:
    config = yaml.safe_load(f)

config["data"]["feature_cols"] = feature_cols
config["data"]["target_col"] = target_cols

config["model"]["input_size"]=len(feature_cols)
config["model"]["output_size"]=len(target_cols)

with open("config.yaml", "w") as f:
    yaml.dump(config, f, sort_keys=False)


feat_scalers = {
    'Temp_mean':RobustScaler(),
    'Temp_std':RobustScaler(),
    'Volt_std':RobustScaler(),
    'Curr_abs_mean':RobustScaler(),
    'Curr_rms':RobustScaler(),
    'EFC_delta':RobustScaler(),
    'EFC_max': MinMaxScaler(),
    'Energy_cumulative': MinMaxScaler(),
    'Energy_throughput': RobustScaler(),
    'R_mean':RobustScaler()
}

# feat_scalers={feat:RobustScaler() for feat in feature_cols}

targ_scaler = {
    'SOH':MinMaxScaler(),
    # 'delta_SOH': StandardScaler()
}




OUT_RAW = ROOT_DIR / "data" / "features_1h"
OUT_RAW.mkdir(parents=True, exist_ok=True)
OUT_SCALED = ROOT_DIR / "data" / "validation_scaled"
OUT_SCALED.mkdir(parents=True, exist_ok=True)

new_path=[]

for n in range(15):
    #
    df = pd.read_parquet(filepaths[n])
    df = df.sort_index()
    
    I_raw=df['Current[A]'].to_numpy()
    U_raw=df['Voltage[V]'].to_numpy()
    T_raw=df['Temperature[°C]']
    SOH_raw=df['SOH'].to_numpy()
    SOC_raw=df['SOC'].to_numpy()

    start_idx=0
    # skip initial rest period
    while abs(I_raw[start_idx]) >1e-3:
        start_idx+=1
    while abs(I_raw[start_idx]) <1e-3:
        start_idx+=1
    print(start_idx)
    fe = FeatureExtractor(window_size=WINDOW_SIZE)
    te = TargetExtractor()

    feat_list=[]
    targ_list=[]
    for i in range(start_idx, len(I_raw)):
        temp=T_raw[i]
        volt=U_raw[i]
        curr=I_raw[i]
        soh=SOH_raw[i]

        fe.add_sample(temp,volt,curr)
        te.add_sample(soh)

        if fe.is_ready():
            feat_tuple=fe.compute_features()
            targ_tuple=te.compute_target()

            feat_arr=np.array(feat_tuple)
            targ_arr=np.array(targ_tuple)
       
            feat_list.append(feat_arr)
            targ_list.append(targ_arr)

            fe.reset_window()
            te.reset_window()
        if i%500000==0:
            print(f"Battery {n+1}, Progress: {(i+1)/len(I_raw)*100:.2f}%")
    
    
    feat_df=pd.DataFrame(feat_list,columns=feature_cols)
    targ_df=pd.DataFrame(targ_list,columns=target_cols)
    result_df=pd.concat([feat_df, targ_df], axis=1)

    #
    out_path=OUT_RAW / f"df_FE_C{nums[n]:02d}_features_1h.parquet" 
    new_path.append(out_path)
    #
    result_df.to_parquet(out_path)
    print(f"Saved scaled features for Battery {n+1} | shape={result_df.shape}")
    #

all_train = []
for idx in idx_tr:
    df_feat = pd.read_parquet(new_path[idx-1])
    all_train.append(df_feat)

df_train = pd.concat(all_train, axis=0)

for col in feature_cols:
    feat_scalers[col].fit(df_train[[col]].values)

for col in target_cols:
    targ_scaler[col].fit(df_train[[col]].values)



joblib.dump({
    "feature_scalers": feat_scalers,
    "target_scaler": targ_scaler
}, "scalers.pkl")

export_scaler_to_c(feat_scalers, targ_scaler, feature_cols) 

print("scalers fitted on 1h features")

#------------------------------------------
# normalize

data = joblib.load("scalers.pkl")

feat_scalers = data["feature_scalers"]
# targ_scaler = data["target_scaler"]

for n in range(1):
    feat_list_scaled = []
    targ_list_scaled = []
    num=nums[n]
    df= pd.read_parquet(OUT_RAW / f"df_FE_C{num:02d}_features_1h.parquet")
    df_feat=df[feature_cols]
    df_targ=df[target_cols]
    
    soh_list=[]
    dsoh_list=[]
    length=df_feat.shape[0]
    for i in range(length):
        feat_scaled = [
            float(scale_one_feature(df_feat[col].iloc[i],feat_scalers[col]))
            for col in feature_cols
                  ]

        # targ_scaled=[
        #     float(scale_one_feature(df_targ[col].iloc[i],targ_scaler[col]))
        #     for col in target_cols
        #         ]
        feat_list_scaled.append(feat_scaled)
        targ_list_scaled.append(df_targ.iloc[i])
    
    
    feat_df_scaled=pd.DataFrame(feat_list_scaled,columns=feature_cols)
    targ_df_scaled=pd.DataFrame(targ_list_scaled,columns=target_cols)
    # result_df_scaled=pd.concat([feat_df_scaled, targ_df_scaled], axis=1)
    out_path_scaled = OUT_SCALED / f"df_FE_C{nums[n]:02d}_features.parquet"
    feat_df_scaled.to_parquet(out_path_scaled)
    out_path_scaled_1 = OUT_SCALED / f"df_FE_C{nums[n]:02d}_output.parquet"
    targ_df_scaled.to_parquet(out_path_scaled_1)
    print(f"Saved scaled features for Battery {n+1} | shape={feat_df_scaled.shape}")

    

