import pandas as pd
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
from ECM_loader import ECMTable

# =====================================
# Load ECM table
# =====================================
ecm = ECMTable()

# =====================================
# Select parameter manually
# Change here freely
# =====================================
param_name = "tau2"


plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = 11
plt.rcParams['mathtext.fontset'] = 'custom'
plt.rcParams['mathtext.rm'] = 'Times New Roman'
plt.rcParams['mathtext.it'] = 'Times New Roman:italic'
plt.rcParams['mathtext.bf'] = 'Times New Roman:bold'
title_str= r"$\tau_2$ [s]"

param_charge = np.array(ecm.tables["charge"][param_name])
param_discharge = np.array(ecm.tables["discharge"][param_name])

soc = np.array(ecm.soc)   # increasing
soh = np.array(ecm.soh)   # increasing

# meshgrid
X, Y = np.meshgrid(soc, soh)

# discharge panel uses decreasing SOC left->right
X_rev = np.meshgrid(soc[::-1], soh)[0]
Z_dis = np.fliplr(param_discharge)

# shared z range
zmin = min(np.nanmin(param_charge), np.nanmin(param_discharge))
zmax = max(np.nanmax(param_charge), np.nanmax(param_discharge))

zticks = np.linspace(zmin, zmax, 6)   
# =====================================
# Plot style
# =====================================


fig = plt.figure(figsize=(14, 14*0.618))

ax1 = fig.add_subplot(121, projection="3d")
ax2 = fig.add_subplot(122, projection="3d")

# =====================================
# Left: Charging
# =====================================
surf1 = ax1.plot_surface(
    X, Y, param_charge,
    cmap="jet",
    edgecolor="none",
    vmin=zmin,
    vmax=zmax
)
ax1.contour(X, Y, param_charge, zdir='z', offset=zmin, cmap='jet')

ax1.set_title(f"Charging")
ax1.set_xlabel("SOC")
ax1.set_ylabel("SOH")
ax1.set_zlabel(param_name)

# =====================================
# Right: Discharging
# =====================================
surf2 = ax2.plot_surface(
    X_rev, Y, Z_dis,
    cmap="jet",
    edgecolor="none",
    vmin=zmin,
    vmax=zmax
)
ax2.contour(X_rev, Y, Z_dis, zdir='z', offset=zmin, cmap='jet')

ax2.set_title(f"Discharging ")
ax2.set_xlabel("SOC")
ax2.set_ylabel("SOH")
ax2.set_zlabel(param_name)

# =====================================
# Ticks formatting
# =====================================
ticks_soc = np.linspace(0, 1, 6)
ticks_soh = np.linspace(min(soh), max(soh), 6)

ax1.set_xticks(ticks_soc)
ax1.set_xticklabels([f"{x:.0%}" for x in ticks_soc])

ax2.set_xticks(ticks_soc[::-1])
ax2.set_xticklabels([f"{x:.0%}" for x in ticks_soc[::-1]])


for ax in [ax1, ax2]:
    ax.set_yticks(ticks_soh)
    ax.set_yticklabels([f"{y:.0%}" for y in ticks_soh])
    ax.set_zticks(zticks)
    ax.view_init(elev=14, azim=130)

# =====================================
# Shared colorbar
# =====================================
cbar = fig.colorbar(
    surf1,
    ax=[ax1, ax2],
    shrink=0.72,
    pad=0.08
)

# label on top

cbar.set_label("")
cbar.ax.set_title(title_str, pad=8)

#plt.suptitle(f"3D SOC-SOH Surface of {param_name}", fontsize=14)
plt.tight_layout()
plt.show()