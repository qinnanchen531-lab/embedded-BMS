step1: Paramter identification:
	- run Param_iden.py  (using RC_fitting.py)
	- save the data in param_1D_xxxx.csv
step2: table generation:
	- run build_param_table.py
	- save the table in ECM_table_(dis)charge.csv
step3: main.py
	- run EKF_fcn.py
	- save the estimation results
