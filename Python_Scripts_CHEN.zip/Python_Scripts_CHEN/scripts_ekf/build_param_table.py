import numpy as np
import pandas as pd
from scipy.interpolate import griddata
from scipy.ndimage import gaussian_filter

def build_param_table(soh_all, soc_all, param_all, soh_edges, soc_edges, sigma=1.0):
    """
    Build SOC-SOH 2D parameter table (ascending order)

    Parameters
    ----------
    soh_all : array-like, shape (N,)
        Original SOH scatter points (unsorted)
    soc_all : array-like, shape (N,)
        Original SOC scatter points (unsorted)
    param_all : array-like, shape (N,)
        Original parameter values (unsorted)
    soh_edges : array-like, shape (M+1,)
        SOH bin edges (ascending)
    soc_edges : array-like, shape (K+1,)
        SOC bin edges (ascending)
    sigma : float, optional
        Standard deviation for Gaussian smoothing (default=1.0)

    Returns
    -------
    P_table : ndarray, shape (M, K)
        Parameter table (rows=SOH, cols=SOC)
    soh_grid : ndarray, shape (M,)
        SOH bin centers
    soc_grid : ndarray, shape (K,)
        SOC bin centers
    N_table : ndarray, shape (M, K)
        Number of samples in each bin
    """

    # =========================
    # 0. Ensure column vectors
    # =========================
    soh_all = np.asarray(soh_all).ravel()
    soc_all = np.asarray(soc_all).ravel()
    param_all = np.asarray(param_all).ravel()

    assert soh_all.size == soc_all.size, "SOH and SOC size mismatch"
    assert soh_all.size == param_all.size, "Param size mismatch"

    # =========================
    # 1. Compute bin centers
    # =========================
    soh_grid=soh_edges + 0.005
    soc_grid=soc_edges + 0.005
    Nsoh, Nsoc = len(soh_grid), len(soc_grid)

    # =========================
    # 2. Assign each point to a bin
    # =========================
    soh_bin = np.digitize(soh_all, soh_edges) - 1  # 0-based indexing
    soc_bin = np.digitize(soc_all, soc_edges) - 1

    # =========================
    # 3. Remove points outside grid
    # =========================
    valid = (soh_bin >= 0) & (soh_bin < Nsoh) & (soc_bin >= 0) & (soc_bin < Nsoc)
    soh_bin = soh_bin[valid]
    soc_bin = soc_bin[valid]
    param_use = param_all[valid]

    # =========================
    # 4. Count samples per bin
    # =========================
    N_table = np.zeros((Nsoh, Nsoc), dtype=int)
    for s, c in zip(soh_bin, soc_bin):
        N_table[s, c] += 1

    # =========================
    # 5. Sum and average parameter per bin
    # =========================
    P_sum = np.zeros((Nsoh, Nsoc), dtype=float)
    for s, c, val in zip(soh_bin, soc_bin, param_use):
        P_sum[s, c] += val

    # Avoid division by zero
    P_table = np.full_like(P_sum, np.nan, dtype=float)
    mask_nonzero = N_table > 0
    P_table[mask_nonzero] = P_sum[mask_nonzero] / N_table[mask_nonzero]

    # =========================
    # 6. Fill missing bins with interpolation
    # =========================
    # Create meshgrid for SOC/SOH centers
    SOCg, SOHg = np.meshgrid(soc_grid, soh_grid)
    mask_valid = ~np.isnan(P_table)

    if np.any(~mask_valid):
        points = np.column_stack((SOCg[mask_valid], SOHg[mask_valid]))
        values = P_table[mask_valid]
        P_table_filled = griddata(points, values,
                                  (SOCg, SOHg),
                                  method='linear')
        # Fill any remaining NaNs with nearest neighbor
        P_table_filled = griddata(points, values,
                                  (SOCg, SOHg),
                                  method='nearest',
                                  fill_value=0) if np.any(np.isnan(P_table_filled)) else P_table_filled
        P_table = P_table_filled

    # =========================
    # 7. Gaussian smoothing
    # =========================
    if sigma > 0:
        P_table = gaussian_filter(P_table, sigma=sigma)

    return P_table, soh_grid, soc_grid, N_table

def build_docv_table(ocv,mode):
    docv=np.zeros_like(ocv)
    if mode=="charge":
        docv[:,:-1]=(ocv[:,1:]-ocv[:,:-1])
        docv[:,-1]=docv[:,-2]
    elif mode=="discharge":
        docv[:,:-1]=(ocv[:,:-1]-ocv[:,1:])
        docv[:,-1]=docv[:,-2]
    else:
        raise ValueError("Invalid mode, must be 'charge' or 'discharge'")
    return docv.astype(np.float32)

#save as CSV
def save_ecm_table(filename, soh_grid, soc_grid,
                   P_Ri, P_R1, P_R2, P_tau1, P_tau2, P_ocv,P_docv):

    SOCg, SOHg = np.meshgrid(soc_grid, soh_grid)

    rows = []
    for i in range(len(soh_grid)):
        for j in range(len(soc_grid)):
            rows.append({
                "SOH": SOHg[i, j],
                "SOC": SOCg[i, j],
                "Ri":  P_Ri[i, j],
                "R1":  P_R1[i, j],
                "R2":  P_R2[i, j],
                "tau1": P_tau1[i, j],
                "tau2": P_tau2[i, j],
                "ocv": P_ocv[i, j],
                "docv": P_docv[i, j]
            })

    df_out = pd.DataFrame(rows)
    df_out.to_csv(filename, index=False)
    print(f"Saved {filename}, shape = {df_out.shape}")


#save as npz
def save_ecm_table_npz(filename,
                       soh_grid, soc_grid,
                       P_Ri_c, P_R1_c, P_R2_c, P_tau1_c, P_tau2_c, P_ocv_c, P_docv_c,
                       P_Ri_dc, P_R1_dc, P_R2_dc, P_tau1_dc, P_tau2_dc, P_ocv_dc, P_docv_dc):

    np.savez_compressed(
        filename,

        soc_grid=soc_grid.astype(np.float32),
        soh_grid=soh_grid.astype(np.float32),

        Ri_charge=P_Ri_c.astype(np.float32),
        R1_charge=P_R1_c.astype(np.float32),
        R2_charge=P_R2_c.astype(np.float32),
        tau1_charge=P_tau1_c.astype(np.float32),
        tau2_charge=P_tau2_c.astype(np.float32),
        ocv_charge=P_ocv_c.astype(np.float32),
        docv_charge=P_docv_c.astype(np.float32),

        Ri_discharge=P_Ri_dc.astype(np.float32),
        R1_discharge=P_R1_dc.astype(np.float32),
        R2_discharge=P_R2_dc.astype(np.float32),
        tau1_discharge=P_tau1_dc.astype(np.float32),
        tau2_discharge=P_tau2_dc.astype(np.float32),
        ocv_discharge=P_ocv_dc.astype(np.float32),
        docv_discharge=P_docv_dc.astype(np.float32)
    )

    print(f"Saved {filename}.npz")

def export_to_c(ECM,c_file="ECM_parameter.c",h_file="ECM_parameter.h"):
    # =========================
    # write .h file
    # =========================
    with open(h_file, "w") as fh:

        fh.write("#ifndef ECM_PARAMETER_H\n#define ECM_PARAMETER_H\n\n")
        fh.write("#include <stdint.h>\n\n")

        # para structs
        for sub_name in ["para_discharge", "para_charge"]:

            sub = ECM[sub_name]

            fh.write(f"typedef struct {{\n")

            for key, arr in sub.items():
                arr = np.asarray(arr)

                if arr.ndim == 1:
                    fh.write(f"    float {key}[{arr.shape[0]}];\n")
                elif arr.ndim == 2:
                    fh.write(f"    float {key}[{arr.shape[0]}][{arr.shape[1]}];\n")

            fh.write(f"}} {sub_name}_t;\n\n")

        # ECM_t
        fh.write("typedef struct {\n")
        fh.write("    para_discharge_t para_discharge;\n")
        fh.write("    para_charge_t para_charge;\n")
        fh.write(f"    float soc[{len(ECM['soc'])}];\n")
        fh.write(f"    float soh[{len(ECM['soh'])}];\n")
        fh.write("} ECM_t;\n\n")
        fh.write("extern const ECM_t ECM;\n\n")

        fh.write("#endif\n")

    # =========================
    # write .c file
    # =========================
    with open(c_file, "w") as fc:

        fc.write(f'#include "{h_file}"\n\n')
        fc.write("const ECM_t ECM = {\n")

        # para data
        for sub_name in ["para_discharge", "para_charge"]:

            sub = ECM[sub_name]
            fc.write(f"    .{sub_name} = {{\n")

            for key, arr in sub.items():
                arr = np.asarray(arr)

                fc.write(f"        .{key} = {{\n")

                if arr.ndim == 1:
                    row = ", ".join(f"{v:.6f}" for v in arr)
                    fc.write(f"            {{ {row} }},\n")

                elif arr.ndim == 2:
                    for r in range(arr.shape[0]):
                        row = ", ".join(f"{v:.6f}" for v in arr[r])
                        fc.write(f"            {{ {row} }},\n")

                fc.write("        },\n")

            fc.write("    },\n")

        # soc
        soc_str = ", ".join(f"{v:.6f}" for v in ECM["soc"])
        fc.write(f"    .soc = {{ {soc_str} }},\n")

        # soh
        soh_str = ", ".join(f"{v:.6f}" for v in ECM["soh"])
        fc.write(f"    .soh = {{ {soh_str} }}\n")

        fc.write("};\n")

    print("✅ ECM_parameter.c / .h generation succeed")    

df = pd.read_csv("param_1D_new.csv")
print(df.columns)

soh_edges = np.arange(0.6, 1.0, 0.01)
soc_edges = np.arange(0.0, 1.0, 0.01)
soh_grid=soh_edges + 0.005
soc_grid=soc_edges + 0.005 




df_charge=df[df["mode"]=="c"]
df_discharge=df[df["mode"]=="dc"]
P_Ri_c, _, _, _ = build_param_table(df_charge["SOH"].values, df_charge["SOC"].values, df_charge["Ri"].values, soh_edges, soc_edges, sigma=1.0)
P_Ri_dc, _, _, _ = build_param_table(df_discharge["SOH"].values, df_discharge["SOC"].values, df_discharge["Ri"].values, soh_edges, soc_edges, sigma=1.0)
P_R1_c, _, _, _ = build_param_table(df_charge["SOH"].values, df_charge["SOC"].values, df_charge["R1"].values, soh_edges, soc_edges, sigma=1.0)
P_R1_dc, _, _, _ = build_param_table(df_discharge["SOH"].values, df_discharge["SOC"].values, df_discharge["R1"].values, soh_edges, soc_edges, sigma=1.0)
P_R2_c, _, _, _ = build_param_table(df_charge["SOH"].values, df_charge["SOC"].values, df_charge["R2"].values, soh_edges, soc_edges, sigma=1.0)
P_R2_dc, _, _, _ = build_param_table(df_discharge["SOH"].values, df_discharge["SOC"].values, df_discharge["R2"].values, soh_edges, soc_edges, sigma=1.0)
P_tau1_c, _, _, _ = build_param_table(df_charge["SOH"].values, df_charge["SOC"].values, df_charge["tau1"].values, soh_edges, soc_edges, sigma=1.0)
P_tau1_dc, _, _, _ = build_param_table(df_discharge["SOH"].values, df_discharge["SOC"].values, df_discharge["tau1"].values, soh_edges, soc_edges, sigma=1.0)
P_tau2_c, _, _, _ = build_param_table(df_charge["SOH"].values, df_charge["SOC"].values, df_charge["tau2"].values, soh_edges, soc_edges, sigma=1.0)
P_tau2_dc, _, _, _ = build_param_table(df_discharge["SOH"].values, df_discharge["SOC"].values, df_discharge["tau2"].values, soh_edges, soc_edges, sigma=1.0)
P_ocv_c, _, _, _ = build_param_table(df_charge["SOH"].values, df_charge["SOC"].values, df_charge["OCV"].values, soh_edges, soc_edges, sigma=1.0)
P_ocv_dc, _, _, _ = build_param_table(df_discharge["SOH"].values, df_discharge["SOC"].values, df_discharge["OCV"].values, soh_edges, soc_edges, sigma=1.0)
P_docv_c=build_docv_table(P_ocv_c,mode="charge")
P_docv_dc=build_docv_table(P_ocv_dc,mode="discharge")

ECM={
    "soc":soc_grid.astype(np.float32),
    "soh": soh_grid.astype(np.float32),

    "para_charge": {
        "Ri": P_Ri_c,
        "R1": P_R1_c,
        "R2": P_R2_c,
        "tau1": P_tau1_c,
        "tau2": P_tau2_c,
        "ocv": P_ocv_c,
        "dOCV": P_docv_c
    },

    "para_discharge": {
        "Ri": P_Ri_dc,
        "R1": P_R1_dc,
        "R2": P_R2_dc,
        "tau1": P_tau1_dc,
        "tau2": P_tau2_dc,
        "ocv": P_ocv_dc,
        "dOCV": P_docv_dc
    }
}



#export_to_c(ECM)
 





save_ecm_table(
    "ECM_table_charge_new.csv",
    soh_grid, soc_grid,
    P_Ri_c, P_R1_c, P_R2_c,
    P_tau1_c, P_tau2_c, 
    P_ocv_c,P_docv_c
)

save_ecm_table(
    "ECM_table_discharge_new.csv",
    soh_grid, soc_grid,
    P_Ri_dc, P_R1_dc, P_R2_dc,
    P_tau1_dc, P_tau2_dc, 
    P_ocv_dc,P_docv_dc
)

