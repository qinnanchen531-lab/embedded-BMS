import numpy as np
from scipy.optimize import least_squares
import matplotlib.pyplot as plt



def RC_fitting(U, I, t):
    """
    2RC ECM parameter identification (Python version of MATLAB RC_fitting)

    Parameters
    ----------
    U : array_like
        Voltage vector
    I : array_like
        Current vector
    t : array_like
        Time vector

    Returns
    -------
    dict
        {
            'Ri': float,
            'R1': float,
            'R2': float,
            'tau1': float,
            'tau2': float,
            'residual': float
        }
    """

    U = np.asarray(U).flatten()
    I = np.asarray(I).flatten()
    t = np.asarray(t).flatten()

    # ------------------ 1. Robust OCV estimation ------------------
    n_tail = max(10, int(len(U) * 0.1))
    OCV = np.median(U[-n_tail:])

    # ------------------ 2. Internal resistance estimation ------------------
    dU = U[1] - U[0]
    dI = I[1] - I[0]

    if abs(dI) < 1e-12:
        raise ValueError("Current variation too small for Ri estimation.")

    Ri = dU / dI

    # ------------------ 3. RC voltage ------------------
    u_rc = U - OCV - Ri * I

    # ------------------ 4. Weighting (emphasize slow dynamics) ------------------
    w = np.linspace(1, 3, len(t))
    sqrtW = np.sqrt(w)

    # ------------------ 5. Model (log(tau) parameterization) ------------------
    def model(p, t):
        A1, A2, log_tau1, log_tau2 = p
        tau1 = np.exp(log_tau1)
        tau2 = np.exp(log_tau2)

        return (
            A1 * np.exp(-t / tau1) +
            A2 * np.exp(-t / tau2)
        )
    def residual(p):
        return sqrtW * (model(p, t) - u_rc)

    # ------------------ 6. Parameter bounds ------------------
    lb = [-1, -1, np.log(1), np.log(20)]
    ub = [ 1,  1, np.log(500), np.log(2000)]

    best_cost = np.inf
    best_p = None

    # ------------------ 7. Multiple random initializations ------------------
    for _ in range(15):
        p0 = np.array([
            u_rc[0] / 2 + 0.01 * np.random.randn(),
            u_rc[0] / 2 + 0.01 * np.random.randn(),
            np.log(30 + 50 * np.random.rand()),
            np.log(200 + 200 * np.random.rand())
        ])

        try:
            result = least_squares(
                residual,
                p0,
                bounds=(lb, ub),
                method='trf',
                verbose=0
            )

            if result.success and result.cost < best_cost:
                best_cost = result.cost
                best_p = result.x

        except Exception:
            continue

    if best_p is None:
        return None
        # raise RuntimeError("RC fitting failed for all initializations.")
        

    # ------------------ 8. Extract parameters ------------------
    A1, A2 = best_p[0], best_p[1]
    tau1 = np.exp(best_p[2])
    tau2 = np.exp(best_p[3])

    if abs(I[0]) < 1e-12:
        raise ValueError("Initial current too small for R calculation.")

    R1 = A1 / I[0]
    R2 = A2 / I[0]
    # u_fit = A1 * np.exp(-t / tau1) + A2 * np.exp(-t / tau2)
    # U_fit = OCV + Ri * I + u_fit
    # plt.figure(figsize=(8,5))

    # plt.plot(t, U, label="Measured Voltage")
    # plt.plot(t, U_fit, '--', label="Model Voltage")

    # plt.xlabel("Time (s)")
    # plt.ylabel("Voltage (V)")
    # plt.title("Voltage Fit Comparison")
    # plt.legend()
    # plt.grid(True)

    # plt.show()

    # ------------------ 9. Output ------------------
    para_opt = {
        "Ri": Ri,
        "R1": R1,
        "R2": R2,
        "tau1": tau1,
        "tau2": tau2,
        "residual": best_cost
    }

    return para_opt