import os
import struct
import numpy as np
import pandas as pd
import serial
import matplotlib.pyplot as plt
import struct
import time

nums = np.arange(1, 30, 2)

this_file = os.path.abspath(__file__)
this_dir = os.path.dirname(this_file)
parent1 = os.path.dirname(this_dir)
parent2 = os.path.dirname(parent1)

filepath = []

for num in nums:
    path = os.path.join(
        parent1,
        "data",
        "rawdata",
        "MGFarm_18650_FE",
        f"df_FE_C{num:02d}.parquet"
    )
    filepath.append(path)
save_dir = os.path.join(parent1, "data", "mcu_soc")
os.makedirs(save_dir, exist_ok=True)
save_path = os.path.join(save_dir, "mcu_soc_C21.parquet")


df = pd.read_parquet(filepath[10])
I = df["Current[A]"].to_numpy()
U = df["Voltage[V]"].to_numpy()
#T = df["Temperature[°C]"].to_numpy()
SoH=df["SOH"].to_numpy()
SoC=df["SOC"].to_numpy()
pack=1

start_idx=800
# while循环直到电流一段时间为0后再继续，用电流为0的最后一个点来初始化
# while abs(I[start_idx]) >1e-3:
#     start_idx+=1
# while abs(I[start_idx]) <1e-3:
#     start_idx+=1
# print(start_idx)



sum=(len(I)-start_idx)//pack




ser = globals().get('ser', None)

if ser is not None:
    ser.close()

ser = serial.Serial(
    port="COM4",
    baudrate=115200,
    timeout=0
)

ser.reset_input_buffer()
ser.reset_output_buffer()

SoC_ekf=np.full(sum, np.nan)

SoC_GT=np.full(sum, np.nan)
ishealthy=np.full(sum, np.nan)

# plt.ion()
# fig, ax = plt.subplots()
# line, = ax.plot([], [], '-o')
# ax.set_xlabel("Time Step[s]")
# ax.set_ylabel("SoC [%]")
# ax.grid(True)
# x_data = []
# y_data = []
# y2_data=[]


header = bytes([0xAA, 0x55])
packer = struct.Struct('fff')
unpacker = struct.Struct('I')
indices = start_idx + np.arange(sum) * pack
rx_buffer = bytearray()
for k, idx in enumerate(indices):
    # ---------- 打包数据 ----------
    if(SoH[idx]<0.95 and SoH[idx]>=0.8):
        SoC_ekf[k] = np.nan
        SoC_GT[k] = np.nan
        ishealthy[k] = np.nan
        continue
    payload = packer.pack(I[idx], U[idx], SoH[idx])
    ser.write(header + payload)

    rx_buffer += ser.read_all()
    while len(rx_buffer) >= 6:
        frame = rx_buffer[:6]
        rx_buffer = rx_buffer[6:]

        if frame[0] == 0xAA and frame[1] == 0x55:
            received = unpacker.unpack(frame[2:6])[0]

            if received == 65535:
                SoC_ekf[k] = np.nan
            else:
                SoC_ekf[k] = received 
        else:
            SoC_ekf[k] = np.nan
        
        SoC_GT[k] = SoC[idx]
    if(SoH[idx]<0.8):
        ishealthy[k]=0
    if(SoH[idx]>=0.95):
        ishealthy[k]=1
    
    if k>900000:
        break
    
    # ---------- 实时绘图/打印----------
    if k % (3600//pack) == 0:
        progress = (k + 1)*pack / len(I) * 100
        print(f"\rProgress: {progress:6.2f}% | {k// (3600//pack)} hours done | SoC={SoC_ekf[k]:.2f}", end='')
    
    # x_data.append(k)  # 转换为分钟
    # y_data.append(SoC_ekf[k])
    # # y2_data.append(SoC_GT[k])
    # line.set_xdata(x_data)
    # line.set_ydata(y_data)
    # # line2, = ax.plot(x_data, y2_data, '-x', color='orange')

    # ax.relim()
    # ax.autoscale_view()

    # plt.pause(0.001)
         

    




# ---------------------------
# 7. 结束
# ---------------------------
ser.close()
#plt.ioff()
#plt.show()
print("max:", np.nanmax(SoC_ekf))
print("min",np.nanmin(SoC_ekf))

plt.figure(figsize=(12, 5))
plt.plot(SoC_ekf)
plt.xlabel("Time Step[s]", fontsize=16)
plt.ylabel("Number of Cycles", fontsize=16)
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.grid(True)
plt.show()
    



# 转成 DataFrame
df_soc = pd.DataFrame({
    "SoC_lstm": SoC_ekf,
    "SoC_GT": SoC_GT,
    "mask": ishealthy
})
df_clean = df_soc.dropna().reset_index(drop=True)
# 保存
# df_clean.to_parquet(save_path, index=False)
print(f"Saved to: {save_path}")

# 计算误差指标
error = SoC_ekf -SoC_GT

mae = np.mean(np.abs(error))
rmse = np.sqrt(np.mean(error ** 2))

print(f"MAE  = {mae:.6f}")
print(f"RMSE = {rmse:.6f}")

# ===== 画图 =====

plt.figure(figsize=(10, 5))

plt.plot(SoC_GT, label="Ground Truth SoC")
plt.plot(SoC_ekf, label="EKF SoC")
plt.title(f"SoC Comparison | MAE={mae:.5f}, RMSE={rmse:.5f}")
plt.xlabel("Cycle / Sample Index")
plt.ylabel("SoC")
plt.legend()
plt.grid(True)

plt.show()
# ------------------------------------------


# df_soc = pd.read_parquet(os.path.join(save_dir, "mcu_soc_C01.parquet"))

# # 


# # mask = df_soc["SoC_lstm"].ne(df_soc["SoC_lstm"].shift())
# # SoC_lstm = df_soc.loc[mask, "SoC_lstm"].iloc[1:].reset_index(drop=True)
# # SoC_GT   = df_soc.loc[mask, "SoC_GT"].iloc[1:].reset_index(drop=True)


# SoC_ekf=df_soc["SoC_lstm"]
# SoC_GT=df_soc["SoC_GT"]
# # dsoh=-0.002714 #每天的基础soh衰减


# # SoH_lstm = np.array(SoH_lstm)

# # SoH_linear_stream = []
# # SoH_corrected = []
# # SoH_linear = []

# # # 初始 baseline
# # baseline = SoH_lstm[0]


# # residual = 0

# # for t in range(len(SoH_lstm)):

# #     # 1️⃣ 预测 baseline（流式）
# #     baseline_t = SoH_lstm[0] + dsoh * t

# #     # 2️⃣ 计算残差
# #     residual_t = SoH_lstm[t] - baseline_t

# #     # 3️⃣ EMA 更新（关键！流式核心）
# #     alpha = 0.1
# #     residual = alpha * residual_t + (1 - alpha) * residual

# #     # 4️⃣ 修正 baseline
# #     corrected = baseline_t + residual
    
       

# #     SoH_linear_stream.append(baseline_t)
# #     SoH_corrected.append(corrected)

# error = np.array(SoC_ekf) - np.array(SoC_GT)

# mae = np.mean(np.abs(error))
# rmse = np.sqrt(np.mean(error ** 2))


# plt.figure(figsize=(10, 5))

# plt.plot(SoC_GT, label="Ground Truth SoC")
# plt.plot(SoC_ekf, label="EKF SoC")
# # plt.plot(SoC_linear, label="Linear Baseline", linestyle='--')
# # plt.plot(SoC_linear_stream, label="Linear Stream", linestyle='-.')
# # plt.plot(SoC_corrected, label="Corrected", linestyle=':')

# plt.title(f"SoC Comparison | MAE={mae:.5f}, RMSE={rmse:.5f}")
# plt.xlabel("Cycle / Sample Index")
# plt.ylabel("SoC")
# plt.legend()
# plt.grid(True)

# plt.show()


