from pathlib import Path
import pandas as pd
import numpy as np
from RC_fitting import RC_fitting



SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent

DATA_DIR=ROOT_DIR/"data"/"rawdata"/"MGFarm_18650_FE"

nums=range(1,30,2)
filepaths=[]

for num in nums:
    path=DATA_DIR/"df_FE_C{num:02d}.parquet".format(num=num)
    filepaths.append(path)


ecm_data_all = {
    "dc": {
        "SOC": [],
        "OCV": [],
        "SOH": [],
        "Ri": [],
        "R1": [],
        "R2": [],
        "tau1": [],
        "tau2": [],
        "battery_id": []
    },
    "c": {
        "SOC": [],
        "OCV": [],
        "SOH": [],
        "Ri": [],
        "R1": [],
        "R2": [],
        "tau1": [],
        "tau2": [],
        "battery_id": []
    }
}

for n in range(15):
    currentT = pd.read_parquet(filepaths[n])

    U = currentT["Voltage[V]"].to_numpy()
    I = currentT["Current[A]"].to_numpy()
    SoH = currentT["SOH"].to_numpy()
    C_rate = currentT["C_Rate"].to_numpy()
    SOC_all=currentT["SOC"].to_numpy()
    
    # ===============================
    # Boundary detection
    # S1:start of discharge, S2:end of discharge, S3:start of charge, S4:end of charge
    # ===============================
    is1C = C_rate >= 0.95
    d = np.diff(np.concatenate(([0], is1C.astype(int), [0])))

    startIdx = np.where(d == 1)[0]
    endIdx = np.where(d == -1)[0] - 1

    valid_2 = np.where((endIdx - startIdx < 50) & (endIdx - startIdx > 20))[0]

    # 
    segments_2 = np.column_stack((startIdx[valid_2], endIdx[valid_2]))


    segments_2[:, 0] -= 1
    
    toDel = []
    for i in range(len(valid_2)):
        if U[segments_2[i, 1]] < 2:  # MATLAB segments_2(i,2)
            toDel.append(i)

    segments_2 = np.delete(segments_2, toDel, axis=0)

   
    segment_ent = np.concatenate((
    [0],
    segments_2.T.flatten(order='F'),  
    [segments_2[-1, 1] + 100000]
    ))
   
    S1, S2, S3, S4 = [], [], [], []

    for i in range(1, len(segment_ent)-1):  
        # Start Entladen
        if segment_ent[i] - segment_ent[i-1] > 70000:
            S1.append(segment_ent[i])
        # Ende Entladen
        if segment_ent[i+1] - segment_ent[i] > 70000:
            S4.append(segment_ent[i])
        # Start Laden
        if 1000 < segment_ent[i] - segment_ent[i-1] < 2000:
            S3.append(segment_ent[i])
        # Ende Laden
        if 1000 < segment_ent[i+1] - segment_ent[i] < 2000:
            S2.append(segment_ent[i])

    
    S1 = np.array(S1)
    S2 = np.array(S2)
    S3 = np.array(S3)
    S4 = np.array(S4)
    # ===============================
    # 2RC parameter identification
    # ===============================
    SOC_dc_all = []
    SOC_c_all = []
    OCV_dc_all = []
    OCV_c_all = []
    SOH_dc_all = []
    SOH_c_all = []
    Ri_dc_all = []
    R1_dc_all = []
    R2_dc_all = []
    tau1_dc_all = []
    tau2_dc_all = []
    Ri_c_all = []
    R1_c_all = []
    R2_c_all = []
    tau1_c_all = []
    tau2_c_all = []
    error_occurred = False
    for i in range(len(S1)):
        print(f'Processing segment {i+1}/{len(S1)} for battery {n+1}') 
        for j in range(len(valid_2)-len(toDel)):
            # ================= discharge=================
            if segments_2[j, 1] <= S2[i] and segments_2[j, 0] >= S1[i]:
                u = U[segments_2[j, 1]:segments_2[j, 1]+362]  
                I1 = I[segments_2[j, 1]:segments_2[j, 1]+362]
                t = np.arange(0, 362)
                result = RC_fitting(u, I1, t)
                if result is None:
                    print(f"RC fitting failed for segment {j} in discharge of battery {n+1}. Skipping this segment.")
                    error_occurred = True
                    continue

                vals = [result['Ri'], result['R1'], result['R2'], result['tau1'], result['tau2']]
                if all(v > 0 and np.isfinite(v) for v in vals):
                    Ri_dc_all.append(result["Ri"])
                    R1_dc_all.append(result["R1"])
                    R2_dc_all.append(result["R2"])
                    tau1_dc_all.append(result["tau1"])
                    tau2_dc_all.append(result["tau2"])
                    SOC_dc_all.append(SOC_all[segments_2[j, 0]])
                    OCV_dc_all.append(U[segments_2[j, 0]])
                    SOH_dc_all.append(SoH[segments_2[j, 0]])
            
            # ================= charge=================
            if segments_2[j, 1] <= S4[i] and segments_2[j, 0] >= S3[i]:
                u = U[segments_2[j, 1]:segments_2[j, 1]+362]
                I1 = I[segments_2[j, 1]:segments_2[j, 1]+362]
                t = np.arange(0, 362)
                result = RC_fitting(u, I1, t)

                vals = [result['Ri'], result['R1'], result['R2'], result['tau1'], result['tau2']]
                if all(v > 0 and np.isfinite(v) for v in vals):
                    Ri_c_all.append(result["Ri"])
                    R1_c_all.append(result["R1"])
                    R2_c_all.append(result["R2"])
                    tau1_c_all.append(result["tau1"])
                    tau2_c_all.append(result["tau2"])
                    SOC_c_all.append(SOC_all[segments_2[j, 0]])
                    OCV_c_all.append(U[segments_2[j, 0]])
                    SOH_c_all.append(SoH[segments_2[j, 0]])
    
    # ===========================
    #de-duplication
    # ===========================
    soc_c_np = np.array(SOC_c_all)
    ocv_c_np = np.array(OCV_c_all)
    soh_c_np = np.array(SOH_c_all)
    Ri_c_np = np.array(Ri_c_all)
    R1_c_np = np.array(R1_c_all)
    R2_c_np = np.array(R2_c_all)
    tau1_c_np = np.array(tau1_c_all)
    tau2_c_np = np.array(tau2_c_all)
    if len(soc_c_np) > 0:
        soc_c_unique, idx = np.unique(soc_c_np, return_index=True)
        ecm_data_all["c"]["SOC"].extend(soc_c_unique.tolist())
        ecm_data_all["c"]["OCV"].extend(ocv_c_np[idx].tolist())
        ecm_data_all["c"]["SOH"].extend(soh_c_np[idx].tolist())
        ecm_data_all["c"]["Ri"].extend(Ri_c_np[idx].tolist())
        ecm_data_all["c"]["R1"].extend(R1_c_np[idx].tolist())
        ecm_data_all["c"]["R2"].extend(R2_c_np[idx].tolist())
        ecm_data_all["c"]["tau1"].extend(tau1_c_np[idx].tolist())
        ecm_data_all["c"]["tau2"].extend(tau2_c_np[idx].tolist())
        ecm_data_all["c"]["battery_id"].extend([n+1]*len(soc_c_unique))

    soc_np = np.array(SOC_dc_all)
    ocv_dc_np = np.array(OCV_dc_all)
    soh_dc_np = np.array(SOH_dc_all)
    Ri_dc_np = np.array(Ri_dc_all)
    R1_dc_np = np.array(R1_dc_all)
    R2_dc_np = np.array(R2_dc_all)
    tau1_dc_np = np.array(tau1_dc_all)
    tau2_dc_np = np.array(tau2_dc_all)
    if len(soc_np) > 0:
        soc_unique, idx = np.unique(soc_np, return_index=True)
        ecm_data_all["dc"]["SOC"].extend(soc_unique.tolist())
        ecm_data_all["dc"]["OCV"].extend(ocv_dc_np[idx].tolist())
        ecm_data_all["dc"]["SOH"].extend(soh_dc_np[idx].tolist())
        ecm_data_all["dc"]["Ri"].extend(Ri_dc_np[idx].tolist())
        ecm_data_all["dc"]["R1"].extend(R1_dc_np[idx].tolist())
        ecm_data_all["dc"]["R2"].extend(R2_dc_np[idx].tolist())
        ecm_data_all["dc"]["tau1"].extend(tau1_dc_np[idx].tolist())
        ecm_data_all["dc"]["tau2"].extend(tau2_dc_np[idx].tolist())
        ecm_data_all["dc"]["battery_id"].extend([n+1]*len(soc_unique))

    print(f'length of param: {len(ecm_data_all["c"]["SOC"])}')
    print(f'length of param: {len(ecm_data_all["dc"]["SOC"])}')

print(f'{n+1} battery finished')



# ===============================
# Convert to DataFrame and save CSV
# ===============================
data_rows = []
for mode in ["dc", "c"]:
    n = len(ecm_data_all[mode]["SOC"])
    for i in range(n):
        row = {k: ecm_data_all[mode][k][i] for k in ["SOC","OCV","SOH","Ri","R1","R2","tau1","tau2"]}
        row["mode"] = mode
        row["battery_id"] = ecm_data_all[mode]["battery_id"][i]
        data_rows.append(row)

df_all = pd.DataFrame(data_rows)
df_all.to_csv("param_1D_new.csv", index=False)
print(f"Saved param_1D_new.csv with {len(df_all)} rows")