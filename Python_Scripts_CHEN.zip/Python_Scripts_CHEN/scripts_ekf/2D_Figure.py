import pandas as pd
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
from ECM_loader import ECMTable

ecm = ECMTable()
param_name = "ocv"
title_str= r"$R_i$ [Ohm]"
param_charge = ecm.tables["charge"][param_name]
param_discharge = ecm.tables["discharge"][param_name]

soc = np.array(ecm.soc)   # increasing
soh = np.array(ecm.soh)   # increasing

Zc = np.array(param_charge)      # shape [SOH, SOC]
Zd = np.array(param_discharge)  # shape [SOH, SOC]

Zd_plot = np.fliplr(Zd)
vmin = min(np.nanmin(Zc), np.nanmin(Zd))
vmax = max(np.nanmax(Zc), np.nanmax(Zd))

#plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = 11

fig = plt.figure(figsize=(12, 5))
gs = fig.add_gridspec(1, 3, width_ratios=[1, 0.05, 1], wspace=0.28)

ax1 = fig.add_subplot(gs[0, 0])
cax = fig.add_subplot(gs[0, 1])
ax2 = fig.add_subplot(gs[0, 2])

im1 = ax1.imshow(
    Zc,
    origin="lower",
    aspect="auto",
    cmap="jet",
    vmin=vmin,
    vmax=vmax
)


im2 = ax2.imshow(
    Zd_plot,
    origin="lower",
    aspect="auto",
    cmap="jet",
    vmin=vmin,
    vmax=vmax
)

cb = fig.colorbar(im1, cax=cax)

cb.set_label("")
cb.ax.set_title(title_str, pad=8)
xticks = np.linspace(0, len(soc)-1, 6, dtype=int)
yticks = np.linspace(0, len(soh)-1, 6, dtype=int)

# Charging axis
ax1.set_xticks(xticks)
ax1.set_xticklabels([f"{soc[i]:.0%}" for i in xticks])

# Discharging axis (reversed labels)
ax2.set_xticks(xticks)
ax2.set_xticklabels([f"{soc[::-1][i]:.0%}" for i in xticks])

# Shared y-axis

ax1.set_yticks(yticks)
ax1.set_yticklabels([f"{soh[i]:.0%}" for i in yticks])
ax1.set_ylabel("SOH")
ax1.set_xlabel("SOC")

ax2.set_yticks([])
ax2.set_xlabel("SOC")

# Titles
ax1.set_title(f"Charging")
ax2.set_title(f"Discharging")

#plt.suptitle(f"SOC-SOH Heatmap of {param_name}", fontsize=13)

plt.tight_layout()
plt.show()
print('Testing ECMTable...')