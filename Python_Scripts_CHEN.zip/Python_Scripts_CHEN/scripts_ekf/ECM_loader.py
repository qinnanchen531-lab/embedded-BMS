import numpy as np
import pandas as pd
from numba import njit
import scipy.io


class ECMTable:
    def __init__(self):

        self.df_ocv_charge=pd.read_csv("ECM_table_charge_new.csv")
        self.df_ocv_discharge=pd.read_csv("ECM_table_discharge_new.csv")

        self.df_rc_charge=pd.read_csv("ECM_table_charge_new.csv")
        self.df_rc_discharge=pd.read_csv("ECM_table_discharge_new.csv")

        # read SOC / SOH
        self.soc = np.sort(self.df_rc_charge["SOC"].unique())
        self.soh = np.sort(self.df_rc_charge["SOH"].unique())
        
        # compute grid info for interpolation
        self.soc_min = self.soc[0]
        self.soc_max = self.soc[-1]
        self.soc_step = self.soc[1] - self.soc[0]

        self.soh_min = self.soh[0]
        self.soh_max = self.soh[-1]
        self.soh_step = self.soh[1] - self.soh[0]
        # read para_discharge and para_charge
        self.tables={
            "charge":self._build_tables(self.df_rc_charge,self.df_ocv_charge),
            "discharge":self._build_tables(self.df_rc_discharge,self.df_ocv_discharge)
        }
        
        
             
  
     

    def _interp_soc(self, soc, row):

        if soc <= self.soc_min:
            return row[0]
        if soc >= self.soc_max:
            return row[-1]

        idx = int((soc - self.soc_min) / self.soc_step)

        x0 = self.soc[idx]
        x1 = self.soc[idx + 1]

        y0 = row[idx]
        y1 = row[idx + 1]

        return y0 + (soc - x0) * (y1 - y0) / (x1 - x0)
    def _get_soh_index(self, soh):

        idx = int(round((soh - self.soh_min) / self.soh_step))
        idx = max(0, min(idx, len(self.soh) - 1))

        return idx
    def _init_soc(self,u,soh):
        charge_tables=self.tables["charge"]
        

        idx_soh=np.argmin(np.abs(self.soh-soh))
        ocv_table=charge_tables["ocv"]
        ocv_row = ocv_table[idx_soh, :]
        soc_est = np.interp(u, ocv_row, self.soc)
        return float(np.clip(soc_est, 0, 1))
    def _build_tables(self, df_rc, df_ocv):
        tables={}
        rc_params=["Ri", "R1", "R2", "tau1", "tau2"]
        ocv_params=["ocv","docv"]
        for param_name in rc_params:
            pivot = df_rc.pivot(
            index="SOH",
            columns="SOC",
            values=param_name
           )
            pivot = pivot.reindex(index=self.soh, columns=self.soc)
            if pivot.isna().values.any():
                raise ValueError(f"{param_name} table contains NaN values")

            tables[param_name] = pivot.values.astype(np.float32)
        for param_name in ocv_params:
            pivot = df_ocv.pivot(
            index="SOH",
            columns="SOC",
            values=param_name
           )
            pivot = pivot.reindex(index=self.soh, columns=self.soc)
            if pivot.isna().values.any():
                raise ValueError(f"{param_name} table contains NaN values")

            tables[param_name] = pivot.values.astype(np.float32)
        
        
        return tables
    
    def get_param(self, soc, soh, I): 
        mode = "charge" if I >= 0 else "discharge" 
        mode_tables=self.tables[mode] 
        # idx_soh=self._get_soh_index(soh) 
        idx_soh=np.argmin(np.abs(self.soh-soh))
        result={} 
        for param_name, table in mode_tables.items(): 
            row=table[idx_soh] 
 
            val=np.interp(soc, self.soc, row)

            result[param_name]=float(val)
        return result


   
    
    
    
   
        

# Test code, uncomment to run
import time


# ecm = ECMTable()
# t0 = time.time()
# val = ecm.get_param(0.5, 1, 0.5)
# print("all:", val)


# print(time.time()-t0)
# t0 = time.time()
# val=ecm.get_param(0.5, 1, 1.)
# print("OCV:", val["ocv"])
# print(time.time()-t0)

# import matplotlib.pyplot as plt
# import numpy as np
# from mpl_toolkits.mplot3d import Axes3D

# ecm = ECMTable()

# mode = "charge"
# param = "Ri"

# Z_c = ecm.tables["charge"][param]
# Z_dc= ecm.tables["discharge"][param]
# SOCg, SOHg = np.meshgrid(ecm.soc, ecm.soh)

# fig = plt.figure()
# plt.plot(ecm.soc, Z_c[-1,:],color='red', label="charge")
# plt.plot(ecm.soc,Z_dc[-1,:], label="discharge")
# plt.xlabel("SOC")
# plt.ylabel("Resistance [Ohm]")
# plt.legend()
# plt.show()
# ax = fig.add_subplot(111, projection='3d')

# # surf = ax.plot_surface(SOCg, SOHg, Z)

# ax.set_xlabel("SOC")
# ax.set_ylabel("SOH")
# ax.set_zlabel(param)
# ax.set_title(f"{mode} {param} 3D Surface")

# # fig.colorbar(surf)
# plt.show()


