import numpy as np

from ECM_loader import ECMTable

import pandas as pd
from config_utils import load_config
from pathlib import Path
import matplotlib.pyplot as plt

class BatteryEKF:
    def __init__(self,soh,U):
        self.ecm=ECMTable()

        soc_0= self.ecm._init_soc(U,soh)
        self.x=np.array([soc_0, 0.0,0.0])
        print(f"intial soc:{soc_0}")
        self.P=np.diag([0.1,0.1,0.1])
       
        self.soh=soh
        self.deltaT=1.0
        self.Q=np.diag([1e-8,2e-3, 2e-3])
        self.R=9e-5

        self.I_nom=1.8
        self.C0=self.I_nom*3600 
        self.Cb=self.C0*soh
     
    
    def predict_update(self,I,Ut,soh):
        self.soh=soh
        self.Cb=self.C0*self.soh

        soc = np.clip(self.x[0], 0, 1)
        
        eff = 1.0
        param=self.ecm.get_param(soc, self.soh, I)
        Ri = param["Ri"]
        R1 = param["R1"]
        R2= param["R2"]
        tau1 = param["tau1"]
        tau2 =param["tau2"]

        
        Ad = np.array([
            [1.0, 0.0, 0.0],
            [0.0, np.exp(-self.deltaT/tau1), 0.0],
            [0.0, 0.0, np.exp(-self.deltaT/tau2)]
        ])
        Bd = np.array([
            eff*self.deltaT/self.Cb,
            R1*(1-np.exp(-self.deltaT/tau1)),
            R2*(1-np.exp(-self.deltaT/tau2))
        ])
        #predict
        x_p = Ad @ self.x + Bd * I
 

    
        P_p = Ad @ self.P @ Ad.T + self.Q
        soc = np.clip(x_p[0],0,1)
        param_p=self.ecm.get_param(x_p[0], self.soh, I)
        
        Ri = param_p["Ri"]
        OCV = param_p["ocv"]
        dOCV = param_p["docv"]

        Cd = np.array([dOCV, 1.0, 1.0])

    
        y_p = OCV +x_p[1] + x_p[2] + Ri*I

        delta_y = Ut - y_p
        S = Cd @ P_p @ Cd.T + self.R     
        K = (P_p @ Cd) / S
    
        dx=K*delta_y   
      
        max_step=abs(I)*self.deltaT/self.Cb*5 
        dx[0] = np.clip(dx[0], -max_step, max_step)
 
        self.x= x_p + dx

        self.x[0] = np.clip(self.x[0], 0, 1)
        
        self.P=(np.eye(3) - np.outer(K, Cd)) @ P_p
        
        
        param_k=self.ecm.get_param(self.x[0], self.soh, I)
        OCV=param_k["ocv"]
        Ri=param_k["Ri"]
        dOCV = param_k["docv"]
        
        
        
        y_k1 = OCV + dOCV + self.x[1] + self.x[2] + Ri*I
        delta_y=Ut-y_k1
       
        
        return self.x,y_k1


