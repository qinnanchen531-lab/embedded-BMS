# import pandas as pd
import pandas as pd
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np

from config_utils import load_config
from EKF_fcn import BatteryEKF
from sklearn.metrics import mean_squared_error, mean_absolute_error

# ==========================================
# High SOH (>95%)
# ==========================================
high_rmse_mcu = np.array([
    0.0245,0.0217,0.0168,0.0219,0.0296,
    0.0251,0.0323,0.0365,0.0256,0.0294,
    0.0320,0.0282,0.0214,0.0134,0.0325
])

high_mae_mcu = np.array([
    0.0206,0.0169,0.0129,0.0175,0.0224,
    0.0196,0.0247,0.0298,0.0205,0.0235,
    0.0252,0.0227,0.0171,0.0096,0.0261
])

high_rmse_py = np.array([
    0.0172,0.0156,0.0137,0.0162,0.0268,
    0.0292,0.0316,0.0371,0.0213,0.0266,
    0.0275,0.0239,0.0183,0.0121,0.0351
])

high_mae_py = np.array([
    0.0136,0.0110,0.0085,0.0119,0.0192,
    0.0222,0.0237,0.0299,0.0163,0.0205,
    0.0216,0.0185,0.0129,0.0082,0.0274
])


# ==========================================
# Low SOH (<80%)
# ==========================================
low_rmse_mcu = np.array([
    0.0542, 0.0913, 0.0884, 0.0336,
    0.0534, 0.0548, 0.0674
])

low_mae_mcu = np.array([
    0.0419, 0.0362, 0.0588, 0.0263,
    0.0418, 0.0417, 0.0481
])

low_rmse_py = np.array([
    0.0421, 0.0199, 0.0494, 0.0226,
    0.0414, 0.0414, 0.0436
])

low_mae_py = np.array([
    0.0321, 0.0158, 0.0357, 0.0168,
    0.0326, 0.0307, 0.0335
])


# ==========================================
# Mean & Std
# ==========================================
def mean_std(x):
    return np.mean(x), np.std(x)

# High SOH
high_rmse_mcu_mean, high_rmse_mcu_std = mean_std(high_rmse_mcu)
high_mae_mcu_mean,  high_mae_mcu_std  = mean_std(high_mae_mcu)

high_rmse_py_mean, high_rmse_py_std = mean_std(high_rmse_py)
high_mae_py_mean,  high_mae_py_std  = mean_std(high_mae_py)

# Low SOH
low_rmse_mcu_mean, low_rmse_mcu_std = mean_std(low_rmse_mcu)
low_mae_mcu_mean,  low_mae_mcu_std  = mean_std(low_mae_mcu)

low_rmse_py_mean, low_rmse_py_std = mean_std(low_rmse_py)
low_mae_py_mean,  low_mae_py_std  = mean_std(low_mae_py)


# # ==========================================
# # Print results
# # ==========================================
# print('========== High SOH (>95%) ==========')
# print(f'MCU RMSE = {high_rmse_mcu_mean:.4f} ± {high_rmse_mcu_std:.4f}')
# print(f'MCU MAE  = {high_mae_mcu_mean:.4f} ± {high_mae_mcu_std:.4f}')
# print(f'PY  RMSE = {high_rmse_py_mean:.4f} ± {high_rmse_py_std:.4f}')
# print(f'PY  MAE  = {high_mae_py_mean:.4f} ± {high_mae_py_std:.4f}')

# print('\n========== Low SOH (<80%) ==========')
# print(f'MCU RMSE = {low_rmse_mcu_mean:.4f} ± {low_rmse_mcu_std:.4f}')
# print(f'MCU MAE  = {low_mae_mcu_mean:.4f} ± {low_mae_mcu_std:.4f}')
# print(f'PY  RMSE = {low_rmse_py_mean:.4f} ± {low_rmse_py_std:.4f}')
# print(f'PY  MAE  = {low_mae_py_mean:.4f} ± {low_mae_py_std:.4f}')


# ==========================================
# Plot: High SOH
# ==========================================
labels = ['RMSE', 'MAE']
x = np.arange(len(labels))
width = 0.35

fig, ax = plt.subplots(figsize=(6,5))

mcu_mean = [high_rmse_mcu_mean, high_mae_mcu_mean]
mcu_std  = [high_rmse_mcu_std,  high_mae_mcu_std]

py_mean = [high_rmse_py_mean, high_mae_py_mean]
py_std  = [high_rmse_py_std,  high_mae_py_std]

ax.bar(
    x - width/2,
    mcu_mean,
    width,
    yerr=mcu_std,
    capsize=5,
    label='MCU',
    color='blue'
)

ax.bar(
    x + width/2,
    py_mean,
    width,
    yerr=py_std,
    capsize=5,
    label='PC',
    color='orange'
)

ax.set_xticks(x)
ax.set_xticklabels(labels, fontsize=16)
ax.set_ylabel('Error', fontsize=16)
ax.tick_params(axis='y', labelsize=16)
# ax.set_title('High SOH (>95%)')
ax.set_ylim(0, 0.085)
ax.legend(fontsize=16)

plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()


# ==========================================
# Plot: Low SOH
# ==========================================
fig, ax = plt.subplots(figsize=(6,5))

mcu_mean = [low_rmse_mcu_mean, low_mae_mcu_mean]
mcu_std  = [low_rmse_mcu_std,  low_mae_mcu_std]

py_mean = [low_rmse_py_mean, low_mae_py_mean]
py_std  = [low_rmse_py_std,  low_mae_py_std]

ax.bar(
    x - width/2,
    mcu_mean,
    width,
    yerr=mcu_std,
    capsize=5,
    label='MCU',
    color='blue'
)

ax.bar(
    x + width/2,
    py_mean,
    width,
    yerr=py_std,
    capsize=5,
    label='PC',
    color='orange'
)

ax.set_xticks(x)
ax.set_xticklabels(labels, fontsize=16)
ax.set_ylabel('Error', fontsize=16)
ax.tick_params(axis='y', labelsize=16)
# ax.set_title('Low SOH (<80%)', fontsize=16)
ax.set_ylim(0, 0.085)
ax.legend(fontsize=16)

plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()

# #读取py和mcu的结果文件
# cfg=load_config()


# SCRIPT_DIR = Path(__file__).resolve().parent
# ROOT_DIR = SCRIPT_DIR.parent

# DATA_DIR=ROOT_DIR/"results"
# DATA_MCU=ROOT_DIR/"data"/"mcu_soc"


# filepaths=[]

# for num in range(15):
#     path=DATA_DIR/"EKF_results_C{num:02d}.parquet".format(num=num+1)
#     filepaths.append(path)

# filepaths_mcu=[]
# for num in range(15):
#     path=DATA_MCU/"mcu_soc_C{num:02d}.parquet".format(num=2*(num+1)-1)
#     filepaths_mcu.append(path)


# rmse_mcu_low=[]
# mae_mcu_low=[]
# rmse_py_low=[]
# mae_py_low=[]
# for n in range(4,5):
#     df = pd.read_parquet(filepaths[n])
#     df_mcu = pd.read_parquet(filepaths_mcu[n])
#     SoC_py = df['SoC_est'].to_numpy()
#     GT_py= df['SoC_true'].to_numpy()
#     U_est=df['U_est'].to_numpy()
#     U_true=df['U_true'].to_numpy()
#     SoC_mcu=df_mcu['SoC_lstm'].to_numpy()
#     GT = df_mcu['SoC_GT'].to_numpy()
#     if (df_mcu['mask'] == 0).any():
#         idx_1=df_mcu.index[df_mcu['mask'] == 0]
#         N=len(idx_1)

#         # rmse_mcu = np.sqrt(mean_squared_error(GT[idx_0], SoC_mcu[idx_0]))
#         # mae_mcu  = mean_absolute_error(GT[idx_0], SoC_mcu[idx_0])

#         # rmse_py = np.sqrt(mean_squared_error(GT_py[-N:], SoC_py[-N:]))
#         # mae_py  = mean_absolute_error(GT_py[-N:], SoC_py[-N:])
#         plt.figure(figsize=(9,5))
#         plt.plot(GT_py[-N:], label='Ground Truth',color='blue')
        
#         plt.plot(SoC_py[-N:], label='PC',color='red')
#         plt.plot(SoC_mcu[idx_1], label='MCU',color='green')
#         plt.xticks(fontsize=16)
#         plt.yticks(fontsize=16)
#         plt.xlabel('Sample', fontsize=16)
#         plt.ylabel('SOC',fontsize=16)
#         plt.legend(fontsize=16,loc='lower right')
#         plt.grid(True)
#         plt.show()

#         # rmse_mcu_low.append(rmse_mcu)
#         # mae_mcu_low.append(mae_mcu)
#         # rmse_py_low.append(rmse_py)
#         # mae_py_low.append(mae_py)
#     else:
#         print(f"Battery C{2*(n+1)-1:02d} has no low SOH data, skipping segment error calculation.")
#         continue
#     # plt.figure(figsize=(12,5))
#     # plt.plot(GT_py[idx_1], label='SoC_GT', linewidth=2)
#     # plt.plot(SoC_mcu[idx_1], label='SoC_mcu')
#     # plt.plot(SoC_py[idx_1], label='SoC_py')
#     # plt.title('rmse_mcu: {:.4f}, mae_mcu: {:.4f}, rmse_py: {:.4f}, mae_py: {:.4f}'.format(rmse_mcu, mae_mcu, rmse_py, mae_py))
#     # plt.xlabel('Sample')
#     # plt.ylabel('SoC')
#     # plt.legend()
#     # plt.grid(True)
#     # plt.show()
#     # print(f"Battery C{2*(n+1)-1:02d}: rmse_mcu={rmse_mcu:.4f}, mae_mcu={mae_mcu:.4f}, rmse_py={rmse_py:.4f}, mae_py={mae_py:.4f}")

# print(f"rmse_mcu_low: {rmse_mcu_low}")
# print(f"mae_mcu_low: {mae_mcu_low}")
# print(f"rmse_py_low: {rmse_py_low}")
# print(f"mae_py_low: {mae_py_low}")



# #分段统计误差，SOH分为低<80%，中80-95%，高>95%三个段，并且增加整体的统计
# # 分段是按段算的
# # overall的统计按电池算的，先算每个电池的overall误差，再算平均和标准差，这样就不会被分段的点重复统计了
# soh_bins = [0, 0.8, 0.95, 1.0]  # 低 <80，中 80-95，高 >95
# soh_labels = ['Low (<80%)','Medium(80-95%)', 'High (>95%)']

# # 初始化存放每个电池每个段的误差
# rmse_all = {label: [] for label in soh_labels}
# mae_all = {label: [] for label in soh_labels}

# # 额外存放整体误差
# rmse_all['Overall'] = []
# mae_all['Overall'] = []

# # 循环处理每个电池
# for n in range(15):
#     df = pd.read_parquet(filepaths[n])
#     soc_true = df['SoC_true'].to_numpy()
#     soc_est = df['SoC_est'].to_numpy()
#     soh = df['SOH'].to_numpy()

#     # 对每个 SOH 段计算 RMSE 和 MAE
#     for i in range(len(soh_bins)-1):
#         mask = (soh > soh_bins[i]) & (soh <= soh_bins[i+1])
#         if mask.sum() == 0:
#             continue
        
#         seg_rmse = np.sqrt(mean_squared_error(soc_true[mask], soc_est[mask]))
#         seg_mae = mean_absolute_error(soc_true[mask], soc_est[mask])
#         print(f"Battery C{2*(n+1)-1:02d} - {soh_labels[i]}: RMSE={seg_rmse:.4f}, MAE={seg_mae:.4f}")   
#         rmse_all[soh_labels[i]].append(seg_rmse)
#         mae_all[soh_labels[i]].append(seg_mae)
        
        

#     # 整体误差（不分段）
#     total_rmse = np.sqrt(mean_squared_error(soc_true, soc_est))
#     total_mae = mean_absolute_error(soc_true, soc_est)
#     rmse_all['Overall'].append(total_rmse)
#     mae_all['Overall'].append(total_mae)
#     # print(f"Battery C{2*(n+1)-1:02d}:RMSE={total_rmse:.4f},MAE={total_mae:.4f}")

# # 增加 Overall 标签
# all_labels = soh_labels + ['Overall']

# # 计算均值和标准差
# rmse_mean = [np.mean(rmse_all[label]) for label in all_labels]
# rmse_std  = [np.std(rmse_all[label]) for label in all_labels]

# mae_mean = [np.mean(mae_all[label]) for label in all_labels]
# mae_std  = [np.std(mae_all[label]) for label in all_labels]

# print("Overall RMSE:", rmse_all['Overall'])
# print("Overall MAE:", mae_all['Overall'])
# print("RMSE Mean:", rmse_mean)
# # print("RMSE Std:", rmse_std)
# # print("MAE Mean:", mae_mean)
# # print("MAE Std:", mae_std)
# # 作误差棒图
# x = np.arange(len(all_labels))
# width = 0.35

# fig, ax = plt.subplots(figsize=(9,5))
# ax.bar(x - width/2, rmse_mean, width, yerr=rmse_std, capsize=5, label='RMSE',color='blue')
# ax.bar(x + width/2, mae_mean, width, yerr=mae_std, capsize=5, label='MAE',color='orange')

# ax.set_xticks(x)

# ax.set_xticklabels(all_labels,fontsize=16)
# ax.set_ylabel('Error',fontsize=16)
# ax.tick_params(axis='y', labelsize=16)
# plt.grid(axis='y', linestyle='--', alpha=0.5)
# # ax.set_title('SOC Estimation Error by SOH Segment and Overall')
# ax.legend(fontsize=16)
# plt.tight_layout()
# plt.show()

# print("RMSE Mean:", rmse_mean)