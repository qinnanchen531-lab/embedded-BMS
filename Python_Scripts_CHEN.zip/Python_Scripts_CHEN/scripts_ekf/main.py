import pandas as pd
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np

from config_utils import load_config
from EKF_fcn import BatteryEKF


def mean_mm(x):
    n = len(x) // 60
    return x[:n*60].reshape(n, 60).mean(axis=1)

def downsample_last(x):
    return [x[i+59] for i in range(0, len(x)-59, 60)]

cfg=load_config()


SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent

DATA_DIR=ROOT_DIR/"data"/"rawdata"/"MGFarm_18650_FE"

nums=range(1,30,2)
filepaths=[]

for num in nums:
    path=DATA_DIR/"df_FE_C{num:02d}.parquet".format(num=num)
    filepaths.append(path)





for n in range(15):

    # use MGFarm_18650_FE
    df=pd.read_parquet(filepaths[n])
    I_raw=df['Current[A]'].to_numpy()
    U_raw=df['Voltage[V]'].to_numpy()
    SOH_raw=df['SOH'].to_numpy()
    SOC_raw=df['SOC'].to_numpy()
    

    I_soc=I_raw
    U_soc=U_raw
    SOH_soc=SOH_raw
    SOC_soc=SOC_raw

    voltage_residual_int = 0.0
    soc_residual_int = 0.0

    SoC_est=[]
    SoC_true=[]
    residual=[]
    U_est=[]
    U_true=[]
    I_true=[]
    SoH=[]
   
    
    
    start_idx=0
    # find the start
    while abs(I_soc[start_idx]) >1e-3:
        start_idx+=1
    while abs(I_soc[start_idx]) <1e-3:
        start_idx+=1
    print(start_idx)
    
    
    ekf = BatteryEKF(SOH_soc[0],U_soc[start_idx-1]) # ekf initialization

    print("ready to run")
    for i in range(start_idx, len(I_soc)):
        
        x,y_k1=ekf.predict_update(I_soc[i],U_soc[i],SOH_soc[i])
     
        SoC_est.append(x[0])
        SoC_true.append(SOC_soc[i])
        U_true.append(U_soc[i])
        SoH.append(SOH_soc[i])
        U_est.append(y_k1)
        
        if i%5000==0:
            print(f"Battery {n+1}, Progress: {(i+1)/len(I_soc)*100:.2f}%")
    
    SoC_true = np.array(SoC_true)
    SoC_est = np.array(SoC_est)


    
    ekf_results={
        "SoC_true": SoC_true,
        "SoC_est": SoC_est,
        "U_est": U_est,
        "U_true": U_true,
        "SOH":SoH
    }
    df_results=pd.DataFrame(ekf_results)
    df_results.to_parquet(ROOT_DIR/"results"/f"EKF_results_C{n+1:02d}.parquet", index=False)
    
   





    
